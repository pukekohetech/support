(function(root, factory){
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.PHSFocusGuard = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function(){
  function hasAttr(el, name){ return !!el && typeof el.hasAttribute === 'function' && el.hasAttribute(name); }
  function getAttr(el, name){ return el && typeof el.getAttribute === 'function' ? el.getAttribute(name) : null; }
  function setAttr(el, name, value){ if (el && typeof el.setAttribute === 'function') el.setAttribute(name, value); }
  function removeAttr(el, name){ if (el && typeof el.removeAttribute === 'function') el.removeAttribute(name); }

  function suspend(el){
    if (!el) return null;
    const tag = String(el.tagName || '').toUpperCase();
    const token = {
      el,
      inert: !!el.inert,
      readOnly: 'readOnly' in el ? !!el.readOnly : undefined,
      hadTabIndex: hasAttr(el, 'tabindex'),
      tabIndex: getAttr(el, 'tabindex'),
      hadAriaDisabled: hasAttr(el, 'aria-disabled'),
      ariaDisabled: getAttr(el, 'aria-disabled'),
      hadContentEditable: hasAttr(el, 'contenteditable'),
      contentEditable: getAttr(el, 'contenteditable')
    };

    try { el.inert = true; } catch (_) {}
    setAttr(el, 'tabindex', '-1');
    setAttr(el, 'aria-disabled', 'true');

    if (tag === 'TEXTAREA' || tag === 'INPUT') {
      try { el.readOnly = true; } catch (_) {}
    } else if (token.hadContentEditable || el.isContentEditable) {
      setAttr(el, 'contenteditable', 'false');
    }
    if (typeof el.blur === 'function') {
      try { el.blur(); } catch (_) {}
    }
    return token;
  }

  function restore(token){
    if (!token || !token.el) return false;
    const el = token.el;
    try { el.inert = token.inert; } catch (_) {}
    if (token.readOnly !== undefined) {
      try { el.readOnly = token.readOnly; } catch (_) {}
    }

    if (token.hadTabIndex) setAttr(el, 'tabindex', token.tabIndex);
    else removeAttr(el, 'tabindex');

    if (token.hadAriaDisabled) setAttr(el, 'aria-disabled', token.ariaDisabled);
    else removeAttr(el, 'aria-disabled');

    if (token.hadContentEditable) setAttr(el, 'contenteditable', token.contentEditable);
    else if (getAttr(el, 'contenteditable') === 'false') removeAttr(el, 'contenteditable');
    return true;
  }

  return { suspend, restore };
});
