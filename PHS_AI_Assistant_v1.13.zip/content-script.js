(() => {
  if (window.__PHS_AI_ASSISTANT_V16__) return;
  window.__PHS_AI_ASSISTANT_V16__ = true;

  const root = window.PHSAI || {};
  if (!root.siteAdapters) {
    console.error('PHS AI Assistant: site adapter did not load.');
    return;
  }

  const PHSAttachmentTools = globalThis.PHSAttachmentTools;
  const PHSFileData = globalThis.PHSFileData;
  const PHSFocusGuard = globalThis.PHSFocusGuard;
  const state = {
    drawerOpen: false,
    view: 'quick',
    fileNote: 'No files added through PHS AI yet.',
    sourceFilesExpected: false,
    selectedSourceFiles: [],
    templatesRequested: false,
    templatesAttached: false,
    shieldRequested: false,
    shieldAttached: false,
    lastStatus: {
      text: 'Choose a workflow, add a little context, and insert the prompt. Nothing is sent automatically.',
      kind: ''
    }
  };

  let focusTokens = [];
  let focusWatch = null;

  function platformName() { return root.siteAdapters.platformName(); }

  function shouldGuardHostComposer() {
    const platform = platformName();
    return platform === 'Claude' || platform === 'Copilot';
  }

  function guardCurrentComposer() {
    if (!state.drawerOpen || !shouldGuardHostComposer() || !PHSFocusGuard) return;
    const composer = root.siteAdapters.findComposer();
    if (!composer || focusTokens.some(token => token?.el === composer)) return;
    const token = PHSFocusGuard.suspend(composer);
    if (token) focusTokens.push(token);
  }

  function startHostFocusGuard() {
    if (!shouldGuardHostComposer() || !PHSFocusGuard || !state.drawerOpen) return;
    guardCurrentComposer();
    if (focusWatch) clearInterval(focusWatch);
    focusWatch = setInterval(guardCurrentComposer, 350);
  }

  function stopHostFocusGuard() {
    if (focusWatch) {
      clearInterval(focusWatch);
      focusWatch = null;
    }
    if (PHSFocusGuard) {
      focusTokens.slice().reverse().forEach(token => {
        try { PHSFocusGuard.restore(token); } catch (_) {}
      });
    }
    focusTokens = [];
  }

  const host = document.createElement('div');
  host.id = 'phs-ai-assistant-host';
  host.style.position = 'fixed';
  host.style.right = '16px';
  host.style.bottom = '24px';
  host.style.zIndex = '2147483646';
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: 'open' });
  const shell = document.createElement('div');
  shadow.appendChild(shell);

  const style = document.createElement('style');
  style.textContent = `
    * { box-sizing:border-box; }
    .phs-host-shell { font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; }
    .phs-shield-launcher {
      width:58px; height:66px; padding:3px; border:0; border-radius:15px;
      background:rgba(255,255,255,.96); box-shadow:0 12px 30px rgba(0,0,0,.25);
      cursor:pointer; display:flex; align-items:center; justify-content:center;
      transition:transform .12s ease, box-shadow .12s ease;
    }
    .phs-shield-launcher:hover { transform:translateY(-2px); box-shadow:0 15px 34px rgba(0,0,0,.28); }
    .phs-shield-launcher:focus-visible, .phs-full-back:focus-visible { outline:3px solid rgba(111,32,48,.3); outline-offset:3px; }
    .phs-shield-launcher img { display:block; max-width:50px; max-height:58px; width:auto; height:auto; }
    .phs-frame-wrap {
      position:relative; width:min(430px,calc(100vw - 24px)); height:min(820px,calc(100vh - 32px));
      min-height:520px; border-radius:18px; overflow:hidden; background:#f7f8f7;
      box-shadow:0 20px 55px rgba(0,0,0,.28);
    }
    .phs-frame-wrap.full { width:min(720px,calc(100vw - 24px)); }
    .phs-assistant-frame { width:100%; height:100%; border:0; display:block; background:#f7f8f7; }
    .phs-full-back {
      position:absolute; top:10px; right:14px; z-index:5; min-height:36px; padding:7px 11px;
      border:1px solid #d8dfdc; border-radius:10px; background:#fff; color:#6f2030;
      font:700 12px/1.2 Inter,ui-sans-serif,system-ui,sans-serif; cursor:pointer;
      box-shadow:0 3px 10px rgba(0,0,0,.12);
    }
    @media (max-width:520px) {
      .phs-frame-wrap, .phs-frame-wrap.full { width:calc(100vw - 16px); height:calc(100vh - 20px); min-height:0; }
    }
  `;
  shadow.prepend(style);

  function currentFrame() { return shadow.getElementById('assistant-frame'); }

  function notifyQuick(text, kind = '', extra = {}) {
    state.lastStatus = { text, kind };
    const frame = currentFrame();
    if (!frame || state.view !== 'quick') return;
    try {
      frame.contentWindow.postMessage({
        type: 'PHS_HOST_STATUS',
        text,
        kind,
        fileNote: state.fileNote,
        ...extra
      }, '*');
    } catch (_) {}
  }

  function notifyFull(message) {
    const frame = currentFrame();
    if (!frame || state.view !== 'full') return;
    try { frame.contentWindow.postMessage(message, '*'); } catch (_) {}
  }

  function notifyCurrent(text, kind = '', extra = {}) {
    state.lastStatus = { text, kind };
    if (state.view === 'full') {
      notifyFull({ type: 'PHS_EXTENSION_STATUS', text, kind, fileNote: state.fileNote, ...extra });
      return;
    }
    notifyQuick(text, kind, extra);
  }

  function renderShell() {
    if (!state.drawerOpen) {
      shell.innerHTML = `<div class="phs-host-shell"><button class="phs-shield-launcher" id="launcher" type="button" title="Open PHS AI Assistant" aria-label="Open PHS AI Assistant"><img src="${chrome.runtime.getURL('Shield.webp')}" alt="Pukekohe High School shield"></button></div>`;
      shadow.getElementById('launcher')?.addEventListener('click', () => setDrawerOpen(true));
      return;
    }

    const isFull = state.view === 'full';
    const src = isFull
      ? chrome.runtime.getURL('full_builder.html')
      : `${chrome.runtime.getURL('quick_frame.html')}?platform=${encodeURIComponent(platformName())}`;
    shell.innerHTML = `<div class="phs-host-shell"><div class="phs-frame-wrap ${isFull ? 'full' : ''}">${isFull ? '<button class="phs-full-back" id="quick-return" type="button">← Quick Builder</button>' : ''}<iframe class="phs-assistant-frame" id="assistant-frame" src="${src}" title="PHS AI Assistant"></iframe></div></div>`;
    shadow.getElementById('quick-return')?.addEventListener('click', () => {
      state.view = 'quick';
      renderShell();
    });
    const frame = currentFrame();
    frame?.addEventListener('load', () => {
      if (state.view === 'quick') {
        try {
          frame.contentWindow.postMessage({
            type: 'PHS_HOST_INIT',
            platform: platformName(),
            fileNote: state.fileNote
          }, '*');
        } catch (_) {}
      }
      try { frame.focus(); } catch (_) {}
    });
  }

  function setDrawerOpen(open) {
    state.drawerOpen = !!open;
    if (state.drawerOpen) startHostFocusGuard();
    else stopHostFocusGuard();
    renderShell();
  }

  function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  function recordSelectedFiles(files) {
    const list = [...(files || [])];
    if (!list.length) return;
    state.sourceFilesExpected = true;
    state.selectedSourceFiles = [...new Set([...state.selectedSourceFiles, ...list.map(file => file.name).filter(Boolean)])].slice(0, 12);
    state.fileNote = `${list.length} file${list.length === 1 ? '' : 's'} selected through ${platformName()}.`;
    notifyCurrent(`${list.length} file${list.length === 1 ? '' : 's'} added through ${platformName()}'s attachment control.`, 'good');
  }

  function chooseSourceFiles() {
    if (!PHSAttachmentTools) {
      notifyCurrent("Attachment helper did not load. Use the AI site's normal paperclip/Attach button.", 'bad');
      return;
    }
    const result = PHSAttachmentTools.openNativePicker(document, recordSelectedFiles);
    if (!result.ok) {
      notifyCurrent(`I could not find ${platformName()}'s file control. Use its normal paperclip/Attach button.`, 'bad');
    } else if (result.mode === 'button') {
      state.fileNote = `${platformName()} attachment menu opened — choose Files, then return to PHS AI.`;
      notifyCurrent(state.fileNote, '');
    }
  }

  async function getUploadInput() {
    let input = PHSAttachmentTools?.findBestFileInput(document) || null;
    if (input) return input;
    const button = PHSAttachmentTools?.findAttachmentButton(document) || null;
    if (!button) return null;
    try { button.click(); } catch (_) { return null; }
    for (let i = 0; i < 8; i += 1) {
      await wait(150);
      input = PHSAttachmentTools.findBestFileInput(document);
      if (input) return input;
    }
    return null;
  }

  async function bundledFile(fileName, mimeType, outputName = fileName) {
    if (!PHSFileData?.isReady?.()) throw new Error('Embedded PHS file data unavailable');
    const file = PHSFileData.makeFileByName(fileName, outputName);
    if (mimeType && file.type !== mimeType) throw new Error(`${fileName} has an unexpected MIME type`);
    return file;
  }

  async function addPHSTemplates() {
    state.templatesRequested = true;
    const input = await getUploadInput();
    if (!input || !PHSAttachmentTools) {
      state.templatesAttached = false;
      state.fileNote = 'Automatic PHS template attachment could not be confirmed. Use the GitHub links in PHS files.';
      notifyCurrent(state.fileNote, 'bad');
      return;
    }
    try {
      const files = [
        await bundledFile('lesson_plan_template_PHS.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
        await bundledFile('Junior_Curriculum_Unit_Plan_Cover_Sheet.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
      ];
      state.templatesAttached = PHSAttachmentTools.assignFiles(input, files);
      if (state.templatesAttached) {
        state.sourceFilesExpected = true;
        state.selectedSourceFiles = [...new Set([...state.selectedSourceFiles, ...files.map(file => file.name)])].slice(0, 12);
      }
    } catch (_) { state.templatesAttached = false; }

    if (state.templatesAttached) {
      state.fileNote = `Both official PHS planning templates are attached to ${platformName()}.`;
      notifyCurrent('PHS lesson-plan and junior unit-plan templates attached.', 'good');
    } else {
      state.fileNote = 'Automatic PHS template attachment was unavailable. Use the GitHub links in PHS files.';
      notifyCurrent(state.fileNote, 'bad');
    }
  }

  async function addPHSShield() {
    state.shieldRequested = true;
    const input = await getUploadInput();
    if (!input || !PHSAttachmentTools) {
      state.shieldAttached = false;
      state.fileNote = 'Automatic shield attachment could not be confirmed. Use the Shield.webp GitHub link in PHS files.';
      notifyCurrent(state.fileNote, 'bad');
      return;
    }
    try {
      const file = await bundledFile('Shield.webp', 'image/webp', 'Shield.webp');
      state.shieldAttached = PHSAttachmentTools.assignFiles(input, [file]);
      if (state.shieldAttached) {
        state.sourceFilesExpected = true;
        state.selectedSourceFiles = [...new Set([...state.selectedSourceFiles, 'Shield.webp'])].slice(0, 12);
      }
    } catch (_) { state.shieldAttached = false; }

    if (state.shieldAttached) {
      state.fileNote = `Official PHS Shield.webp attached to ${platformName()}.`;
      notifyCurrent('PHS shield attached.', 'good');
    } else {
      state.fileNote = 'Automatic shield attachment was unavailable. Use the Shield.webp GitHub link in PHS files.';
      notifyCurrent(state.fileNote, 'bad');
    }
  }

  function attachmentContext(prompt) {
    const notes = [];
    if (state.sourceFilesExpected) {
      const names = state.selectedSourceFiles.length ? ` Files selected/attached: ${state.selectedSourceFiles.join(', ')}.` : '';
      notes.push(`Use the files attached to this AI message as working material.${names} When asked to fill, update, review, or complete a document, preserve its existing structure, headings, tables, and useful formatting. Return an updated editable file when supported.`);
    }
    if (state.templatesRequested) {
      if (state.templatesAttached) notes.push('The exact PHS lesson-plan and junior unit-plan DOCX templates are attached. Preserve their exact headings, tables, order, wording, and editable DOCX structure. Do not recreate a lookalike template.');
      else notes.push('PHS planning templates were requested but attachment was not confirmed. Do not claim to have read or filled them unless the teacher attaches them.');
    }
    if (state.shieldRequested) {
      if (state.shieldAttached) notes.push('The official PHS shield is attached as Shield.webp. Use that exact asset and preserve its proportions.');
      else notes.push('PHS branding was requested but Shield.webp attachment was not confirmed. Do not fabricate or substitute another crest.');
    }
    return notes.length ? `${prompt}\n\n## FILES / BRANDING PROVIDED BY PHS AI\n- ${notes.join('\n- ')}` : prompt;
  }

  async function copyPromptText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      try {
        const temp = document.createElement('textarea');
        temp.value = text;
        temp.style.position = 'fixed';
        temp.style.opacity = '0';
        document.body.appendChild(temp);
        temp.focus();
        temp.select();
        const ok = document.execCommand('copy');
        temp.remove();
        return ok;
      } catch (_) { return false; }
    }
  }

  function insertFromFrame(prompt, sourceLabel = 'Prompt') {
    const finalPrompt = attachmentContext(String(prompt || '').trim());
    if (!finalPrompt) {
      notifyCurrent('No finished prompt was available yet.', 'bad');
      return;
    }
    stopHostFocusGuard();
    const result = root.siteAdapters.insertPrompt(finalPrompt);
    if (result.ok) {
      state.drawerOpen = false;
      state.view = 'quick';
      renderShell();
      return;
    }
    startHostFocusGuard();
    notifyCurrent(`I could not find ${platformName()}'s message box. Use Copy prompt instead.`, 'bad', { showPreview: true });
  }

  async function copyFromFrame(prompt) {
    const finalPrompt = attachmentContext(String(prompt || '').trim());
    if (!finalPrompt) {
      notifyCurrent('No finished prompt was available yet.', 'bad');
      return;
    }
    const ok = await copyPromptText(finalPrompt);
    notifyCurrent(ok ? 'Prompt copied. Paste it into the AI chat box and press Send manually.' : 'Copy failed in this browser. Use the generated prompt preview to copy manually.', ok ? 'good' : 'bad', { showPreview: true });
  }

  document.addEventListener('change', event => {
    if (!state.drawerOpen) return;
    const target = event.target;
    if (target instanceof HTMLInputElement && target.type === 'file' && target.files?.length) recordSelectedFiles(target.files);
  }, true);

  window.addEventListener('message', event => {
    const frame = currentFrame();
    if (!frame || event.source !== frame.contentWindow) return;
    const data = event.data || {};

    if (state.view === 'quick') {
      if (data.type === 'PHS_QUICK_READY') {
        try { frame.contentWindow.postMessage({ type: 'PHS_HOST_INIT', platform: platformName(), fileNote: state.fileNote }, '*'); } catch (_) {}
        return;
      }
      if (data.type === 'PHS_QUICK_COLLAPSE') { setDrawerOpen(false); return; }
      if (data.type === 'PHS_QUICK_FULL_BUILDER') {
        state.view = 'full';
        renderShell();
        return;
      }
      if (data.type === 'PHS_QUICK_INSERT') { insertFromFrame(data.prompt, 'Quick Builder'); return; }
      if (data.type === 'PHS_QUICK_COPY') { copyFromFrame(data.prompt); return; }
      if (data.type === 'PHS_QUICK_ACTION') {
        if (data.action === 'attach-files') chooseSourceFiles();
        else if (data.action === 'attach-templates') addPHSTemplates();
        else if (data.action === 'attach-shield') addPHSShield();
        return;
      }
    }

    if (state.view === 'full') {
      if (data.type === 'PHS_FULL_READY') {
        notifyFull({
          type: 'PHS_EXTENSION_READY',
          version: chrome.runtime.getManifest().version,
          capabilities: { insert: true, copy: true, attachments: true }
        });
        return;
      }
      if (data.type === 'PHS_FULL_INSERT') { insertFromFrame(data.prompt, 'Full Builder'); return; }
      if (data.type === 'PHS_FULL_COPY') { copyFromFrame(data.prompt); return; }
      if (data.type === 'PHS_FULL_ACTION') {
        if (data.action === 'attach-files') chooseSourceFiles();
        else if (data.action === 'attach-templates') addPHSTemplates();
        else if (data.action === 'attach-shield') addPHSShield();
        return;
      }
    }
  });

  renderShell();
})();
