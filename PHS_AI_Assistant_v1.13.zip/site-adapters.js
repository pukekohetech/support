(() => {
  const root = window.PHSAI = window.PHSAI || {};
  const hostname = location.hostname.toLowerCase();

  function platformName() {
    if (hostname.includes('chatgpt') || hostname.includes('openai')) return 'ChatGPT';
    if (hostname.includes('claude')) return 'Claude';
    if (hostname.includes('copilot') || hostname.includes('m365')) return 'Copilot';
    return 'AI chat';
  }

  function isVisible(el) {
    if (!(el instanceof HTMLElement)) return false;
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 180 && rect.height > 20 && rect.bottom > 0 && rect.top < innerHeight;
  }

  function isEditable(el) {
    if (!el || !isVisible(el)) return false;
    if (el.matches('textarea')) return !el.disabled && !el.readOnly;
    return el.getAttribute('contenteditable') === 'true';
  }

  function preferredSelectors() {
    if (platformName() === 'ChatGPT') {
      return [
        '#prompt-textarea',
        "textarea[data-testid*='prompt']",
        "div[contenteditable='true'][data-lexical-editor='true']",
        "div[contenteditable='true'][role='textbox']"
      ];
    }
    if (platformName() === 'Claude') {
      return [
        "div.ProseMirror[contenteditable='true']",
        "div[contenteditable='true'][role='textbox']",
        "fieldset div[contenteditable='true']",
        'textarea'
      ];
    }
    return [
      "textarea[placeholder*='Message' i]",
      "textarea[placeholder*='Ask' i]",
      "div[contenteditable='true'][role='textbox']",
      'textarea',
      "div[contenteditable='true']"
    ];
  }

  function findComposer() {
    for (const selector of preferredSelectors()) {
      const visible = [...document.querySelectorAll(selector)].filter(isEditable);
      if (visible.length) {
        visible.sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
        return visible[0];
      }
    }
    const fallback = [...document.querySelectorAll('textarea, [contenteditable=true]')].filter(isEditable);
    fallback.sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
    return fallback[0] || null;
  }

  function currentText(el) {
    return el.matches('textarea') ? (el.value || '') : (el.innerText || el.textContent || '');
  }

  function setTextarea(el, text) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(el, text);
    else el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setContentEditable(el, text) {
    el.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);

    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch (_) {}

    if (!inserted || !currentText(el).trim()) {
      el.textContent = text;
      try {
        el.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          inputType: 'insertText',
          data: text
        }));
      } catch (_) {
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function insertPrompt(prompt) {
    const composer = findComposer();
    if (!composer) return { ok: false, reason: 'composer-not-found' };
    const existing = currentText(composer).trim();
    const combined = existing ? `${existing}\n\n${prompt}` : prompt;
    composer.focus();
    if (composer.matches('textarea')) setTextarea(composer, combined);
    else setContentEditable(composer, combined);
    composer.focus();
    try { composer.scrollIntoView({ block: 'nearest' }); } catch (_) {}
    return { ok: true, appendedToExisting: !!existing };
  }

  root.siteAdapters = {
    platformName,
    insertPrompt,
    findComposer
  };
})();
