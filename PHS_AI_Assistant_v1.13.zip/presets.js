(() => {
  const root = window.PHSAI = window.PHSAI || {};

  root.yearLevels = [
    'Staff / PLD', 'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13', 'Mixed / multi-level'
  ];

  root.teachingYears = [
    'Current year', '2026', '2027', 'Future / planning ahead'
  ];

  root.defaults = {
    mode: 'curriculum',
    curriculumWorkflow: 'checkAlignment',
    resourceWorkflow: 'powerpoint',
    yearLevel: 'Year 9',
    intendedTeachingYear: 'Current year'
  };

  root.modeConfig = {
    curriculum: {
      key: 'curriculum',
      label: 'Curriculum',
      intro: 'Fast curriculum support for alignment, improvement, and planning documents.',
      workflows: [
        { id: 'checkAlignment', label: 'Check alignment', sublabel: 'KEEP / CHANGE / ADD / VERIFY' },
        { id: 'improveAlign', label: 'Improve & align', sublabel: 'Review it, then improve it' },
        { id: 'completeDocument', label: 'Complete full document', sublabel: 'Fill the attached planning/template file' },
        { id: 'createNewUnit', label: 'Create new unit', sublabel: 'Build from scratch' },
        { id: 'whatChanged', label: 'What changed?', sublabel: 'Explain the curriculum changes' }
      ],
      fields: [
        { id: 'yearLevel', label: 'Year level', type: 'select', optionsSource: 'yearLevels', required: true },
        { id: 'intendedTeachingYear', label: 'Intended teaching year', type: 'select', optionsSource: 'teachingYears', required: true },
        { id: 'subject', label: 'Subject / learning area', type: 'select', optionsResolver: 'curriculumSubjectOptions', required: true },
        { id: 'customSubject', label: 'Your subject / learning area', type: 'text', placeholder: 'Type the subject or local course name', visibleWhen: 'customSubject', required: false },
        {
          id: 'curriculumFocus',
          label: 'Curriculum focus / strand to align',
          type: 'select',
          optionsResolver: 'curriculumFocusOptions',
          helpResolver: 'curriculumSourceHelp',
          requiredFor: ['checkAlignment', 'improveAlign']
        },
        { id: 'customCurriculumFocus', label: 'Your curriculum focus / strand', type: 'text', placeholder: 'Type the strand, focus, or local curriculum scope', visibleWhen: 'customCurriculumFocus', required: false },
        { id: 'topic', label: 'Unit / topic (optional)', type: 'text', placeholder: 'e.g. Measurement and Scale', required: false },
        { id: 'extraInfo', label: 'Extra information (optional)', type: 'textarea', placeholder: 'Anything the AI should know about the unit, learners, school context, or what you want checked.' }
      ]
    },
    create: {
      key: 'create',
      label: 'Create Resource',
      intro: 'Generate a prompt for a teaching resource quickly.',
      workflows: [
        { id: 'powerpoint', label: 'PowerPoint', sublabel: 'Editable teaching deck' },
        { id: 'worksheet', label: 'Worksheet', sublabel: 'Printable classroom task' },
        { id: 'infographic', label: 'Infographic', sublabel: 'High-quality visual summary' },
        { id: 'reliefPack', label: 'Relief pack', sublabel: 'Teacher-ready relief lesson' },
        { id: 'assessmentTeams', label: 'Assessment / Teams', sublabel: 'Task, instructions, or package' },
        { id: 'interactive', label: 'Interactive resource', sublabel: 'HTML/tool/game style output' },
        { id: 'custom', label: 'Custom', sublabel: 'Something else' }
      ],
      fields: [
        { id: 'yearLevel', label: 'Year level', type: 'select', optionsSource: 'yearLevels', required: true },
        { id: 'subject', label: 'Subject / topic area', type: 'text', placeholder: 'e.g. Design and Visual Communication', required: true },
        { id: 'topic', label: 'Topic', type: 'text', placeholder: 'e.g. Shape extraction', required: true },
        { id: 'learningGoal', label: 'Learning goal / purpose', type: 'textarea', placeholder: 'What should learners understand, practise, or produce?', required: true },
        { id: 'extraInfo', label: 'Extra information (optional)', type: 'textarea', placeholder: 'Any notes, constraints, learner needs, style requests, or attached-source guidance.' }
      ]
    }
  };

  root.fieldsForWorkflow = function(mode, workflowId) {
    const config = root.modeConfig && root.modeConfig[mode];
    if (!config) return [];
    return (config.fields || []).map(field => {
      const requiredFor = Array.isArray(field.requiredFor) ? field.requiredFor : null;
      return { ...field, required: requiredFor ? requiredFor.includes(workflowId) : Boolean(field.required) };
    });
  };

  root.resourceExtraFields = {
    powerpoint: [
      { id: 'lessonLength', label: 'Lesson / use length', type: 'select', options: ['Not specified', '30 minutes', '45 minutes', '60 minutes', 'Double period / longer'], defaultValue: '45 minutes' }
    ],
    worksheet: [
      { id: 'pageCount', label: 'Approximate page count', type: 'select', options: ['1 page', '2 pages', '3–4 pages', 'As needed'], defaultValue: '1 page' }
    ],
    infographic: [
      { id: 'orientation', label: 'Orientation', type: 'select', options: ['Portrait', 'Landscape'], defaultValue: 'Portrait' },
      { id: 'useType', label: 'Primary use', type: 'select', options: ['Print + screen', 'Print only', 'Screen only'], defaultValue: 'Print + screen' }
    ],
    reliefPack: [
      { id: 'lessonLength', label: 'Lesson length', type: 'select', options: ['30 minutes', '45 minutes', '60 minutes', 'Double period / longer'], defaultValue: '45 minutes' },
      { id: 'deviceAvailability', label: 'Devices available?', type: 'select', options: ['Not specified', 'Yes - 1:1 devices', 'Some devices / pair up', 'No devices'], defaultValue: 'Not specified' }
    ],
    assessmentTeams: [
      { id: 'assessmentContext', label: 'Assessment context', type: 'select', options: ['General classroom assessment', 'NCEA / standards-based', 'Microsoft Teams task / package'], defaultValue: 'General classroom assessment' }
    ],
    interactive: [
      { id: 'interactiveType', label: 'Interactive type', type: 'select', options: ['Not specified', 'Single self-contained HTML', 'Quiz / revision game', 'Interactive tool / calculator', 'Simulation / visual explainer'], defaultValue: 'Single self-contained HTML' }
    ],
    custom: [
      { id: 'customOutput', label: 'What do you want created?', type: 'text', placeholder: 'e.g. student booklet, poster series, parent email pack', required: true }
    ]
  };


  root.quickTweaks = {
    powerpoint: [
      { id: 'staffPld', label: 'Staff / PLD', prompt: 'Pitch the presentation for staff professional learning: concise explanation, practical implications, credible evidence, and immediately usable teacher takeaways.' },
      { id: 'questionReveal', label: 'Question → reveal', prompt: 'Use reliable question-before-answer reveal sequences where they support learning, preferably duplicate-slide reveals when animation cannot be verified.' },
      { id: 'workedExamples', label: 'Worked examples', prompt: 'Include clear worked examples or modelled reasoning where they materially improve understanding. Verify each example and answer independently.' }
    ],
    worksheet: [
      { id: 'lowWriting', label: 'Low writing', prompt: 'Keep writing demand low while preserving the learning. Prefer concise responses, matching, labelling, tables, diagrams, sorting, or short structured answers where appropriate.' },
      { id: 'reliefReady', label: 'Relief-ready', prompt: 'Make the worksheet usable in a relief lesson with clear independent instructions and minimal need for specialist teacher explanation.' },
      { id: 'withAnswers', label: 'With answers', prompt: 'Include a concise teacher answer key or model responses and cross-check every answer against the exact student task.' }
    ],
    infographic: [
      { id: 'studentReference', label: 'Student reference', prompt: 'Optimise the infographic as a student reference that can be scanned quickly while retaining accurate subject terminology and essential learning.' },
      { id: 'staffPld', label: 'Staff / PLD', prompt: 'Pitch the infographic for staff professional learning with credible evidence, practical implications, and concise teacher-facing language.' },
      { id: 'technicalDiagram', label: 'Technical diagram', prompt: 'Use an accurate labelled technical diagram or annotated visual as the dominant teaching device where appropriate; verify orientation, labels, proportions, and relationships.' }
    ],
    reliefPack: [
      { id: 'noDevices', label: 'No devices', prompt: 'Design the lesson so students can complete it without devices.' },
      { id: 'someDevices', label: 'Some devices', prompt: 'Design for limited device access so students without a device can pair up or complete an equivalent supported route.' },
      { id: 'practicalLesson', label: 'Practical lesson', prompt: 'Design this for a practical lesson. Preserve teacher-supplied practical constraints and safety instructions, and do not invent operating procedures.' }
    ],
    assessmentTeams: [
      { id: 'ncea', label: 'NCEA', prompt: 'Treat this as an NCEA-related resource. Verify the exact current official standard, version, credits, criteria, and other consequential assessment details before using them; do not guess.' },
      { id: 'teamsAssignment', label: 'Teams assignment', prompt: 'Structure the student-facing instructions so they can be pasted cleanly into Microsoft Teams, with clear task steps and submission expectations drawn only from supplied or verified information.' },
      { id: 'markingGuide', label: 'Marking guide', prompt: 'Include a concise teacher marking guide or evidence checklist that maps to the actual task and verified criteria without inventing requirements.' }
    ],
    interactive: [
      { id: 'revisionGame', label: 'Revision game', prompt: 'Make the interaction a purposeful revision game with accurate feedback and content rather than decorative gamification.' },
      { id: 'calculatorTool', label: 'Calculator / tool', prompt: 'Build this as a practical calculator or classroom tool. Verify formulas independently and test normal, boundary, and invalid inputs.' },
      { id: 'teacherTool', label: 'Teacher tool', prompt: 'Optimise the interaction as a practical teacher-facing classroom tool with fast controls, clear output, and reliable state handling.' }
    ],
    custom: [
      { id: 'studentFacing', label: 'Student-facing', prompt: 'Pitch the final output directly to students at the stated year level using clear, age-appropriate language and an obvious reading path.' },
      { id: 'staffFacing', label: 'Staff-facing', prompt: 'Pitch the final output for teachers or school staff with professional language, concise rationale, and practical implementation detail.' },
      { id: 'parentCommunication', label: 'Parent communication', prompt: 'Pitch the final output for parents/whānau: clear, respectful, factual, concise, and free of unsupported claims or unnecessary school jargon.' }
    ]
  };

  root.moreOptionsConfig = [
    { id: 'lowWritingLoad', label: 'Low writing load', type: 'checkbox' },
    { id: 'visualScaffolding', label: 'Strong visual scaffolding', type: 'checkbox' },
    { id: 'printFriendly', label: 'Print-friendly output', type: 'checkbox' },
    { id: 'includeAnswers', label: 'Include answers / teacher notes', type: 'checkbox' },
    { id: 'phsBranding', label: 'PHS branding', type: 'checkbox' },
    { id: 'chatTitle', label: 'Chat title override (optional · max 40)', type: 'text', maxLength: 40, placeholder: 'e.g. Y9 Tech – Picture Frame' },
    { id: 'lessonOrUseLength', label: 'Lesson / use length override', type: 'text', placeholder: 'e.g. 45 minutes, 2 periods, ongoing reference' },
    { id: 'outputScale', label: 'Output scale / size', type: 'text', placeholder: 'e.g. 10 slides, 2-page worksheet, A4 portrait' },
    { id: 'learnerNeeds', label: 'Specific learner needs', type: 'textarea', placeholder: 'e.g. ADHD/autism, dyslexia-friendly, low reading age' },
    { id: 'visualDirection', label: 'Visual direction', type: 'text', placeholder: 'e.g. simple, clean, modern, photorealistic, minimal' },
    { id: 'deliveryEnvironment', label: 'Delivery environment', type: 'text', placeholder: 'e.g. no projector, classroom display, homework, relief cover' },
    { id: 'requiredFeatures', label: 'Required features', type: 'textarea', placeholder: 'List anything that must be included.' },
    { id: 'avoidFeatures', label: 'Features to avoid', type: 'textarea', placeholder: 'List anything that should be avoided.' }
  ];
})();
