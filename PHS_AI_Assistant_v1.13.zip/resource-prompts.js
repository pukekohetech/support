(() => {
  const root = window.PHSAI = window.PHSAI || {};

  root.resourcePrompts = {
    powerpoint: {
      quickPrompt: 'PowerPoint',
      action: 'Create new',
      title: 'PowerPoint',
      artifact: 'Editable teaching PowerPoint (.pptx)',
      purpose: `Create a polished editable teaching PowerPoint that is accurate, well researched where needed, and designed to teach rather than merely summarise.`,
      task: `# ARTIFACT: POLISHED EDITABLE TEACHING POWERPOINT

Create and return a valid editable .pptx that actively teaches rather than merely summarises.

## TEACHING ARCHITECTURE
- Choose slide count from the learning need and use time; do not pad.
- Give each slide one dominant teaching purpose.
- Use a coherent progression such as hook/recall → explanation/model → guided check → application → recap when appropriate.
- Anticipate likely misconceptions and correct them where relevant.
- Use question-before-answer sequences where they improve learning. If animation cannot be created and verified, prefer reliable duplicate-slide reveals.
- Check that question and answer pairs agree and that examples do not contradict the explanation.

## PROFESSIONAL DESIGN DEFAULTS
- Keep a minimum student-facing font size of 24 pt.
- Use strong hierarchy, deliberate spacing, readable editable text, and purposeful instructional visuals.
- Avoid generic AI-deck clutter, repeated card grids, tiny decorative images, excessive gradients, and dense paragraphs.
- Keep important teaching text, labels, diagrams, tables, and arrows editable where practical.
- Use speaker notes for sources, teaching guidance, answers, and misconceptions where useful.

## RESEARCH AND SOURCES
- Verify current, technical, specialised, official, or uncertain claims before using them.
- For researched claims, record concise source details in speaker notes or a short source slide where appropriate; do not clutter student-facing slides unnecessarily.

## PRODUCTION QA
- Render and visually inspect every slide where tools permit.
- Check dimensions, clipping, overflow, minimum font size, awkward wrapping, image proportions/crops, alignment, notes, links, and whole-deck consistency.
- Perform a spelling/grammar/terminology pass over the actual slide content.
- Fix detected problems before delivery.
- Do not claim Microsoft PowerPoint testing unless it actually occurred.`,
      fieldsNote: `If an existing slide deck, notes, or source material is attached, preserve strong content and useful links/notes while improving only what materially helps accuracy, teaching, or visual communication.`
    },

    worksheet: {
      quickPrompt: 'Worksheet',
      action: 'Create new',
      title: 'Worksheet',
      artifact: 'Printable worksheet',
      purpose: `Create a polished, accurate classroom worksheet that is age-appropriate, answerable, and ready to use.`,
      task: `# ARTIFACT: CLASSROOM WORKSHEET

Create a finished classroom-ready worksheet suitable for the stated year level and learning purpose.

## LEARNING DESIGN
- Teach before testing: explain/model the essential content before asking students to apply it unless the task is explicitly retrieval of previously taught knowledge.
- Every student task must be answerable from the worksheet, supplied source, or clearly stated accessible prior knowledge.
- Make instructions unambiguous and keep reading load and writing demand appropriate to the learners.
- Use purposeful formats such as short responses, matching, labelling, tables, diagrams, sorting, worked examples, or structured paragraphs when they suit the learning.
- Avoid filler questions and repeated testing of the same idea.

## ANSWER RELIABILITY
- Check every answer or model response against the exact student question.
- Check answer-key numbering and wording match the student version.
- Recalculate any numerical answers independently and verify units.
- Do not create an answer key that introduces facts not taught or supported by the resource.

## PRINT / FILE QA
- Use readable type, comfortable writing space, predictable sections, and clear page flow.
- Render or inspect printable output where tools permit.
- Check page breaks, clipping, margins, question numbering, answer-key separation, spelling, grammar, and terminology before delivery.

If an editable file can be produced reliably, provide it. Otherwise provide the finished classroom-ready worksheet in the best supported format.`,
      fieldsNote: `If a source text, activity, or existing worksheet is attached, preserve useful content and adapt it rather than replacing it with generic material.`
    },

    infographic: {
      quickPrompt: 'Infographic',
      action: 'Create new',
      title: 'Infographic',
      artifact: 'High-resolution infographic PNG',
      purpose: `Create a polished, accurate educational infographic whose visuals improve understanding and whose text is reliable and readable.`,
      task: `# ARTIFACT: HIGH-QUALITY EDUCATIONAL INFOGRAPHIC

Create and return a finished high-resolution infographic image.

## LEARNING AND VISUAL STORY
- Build around approximately five essential ideas, using fewer for a genuinely simple topic and more only when accuracy requires it.
- Prefer meaningful diagrams, flows, comparisons, annotated examples, timelines, or relationships over paragraphs in coloured boxes.
- Use a clear reading path, strong hierarchy, whitespace, and readable text suitable for the intended print/screen size.
- Keep accessibility as a baseline: short chunks, predictable grouping, strong contrast, and no reliance on colour alone.

## TEXT ACCURACY
- Do not trust an image-generation model with essential instructional text.
- Where generated imagery is used, generate artwork/visual components separately where practical and add headings, labels, numbers, and instructional text with a reliable text-rendering/layout method.
- Check spelling, punctuation, terminology, labels, arrows, values, and captions independently.

## RENDERED-IMAGE QA
- Inspect the actual finished image where tools permit.
- Check for corrupted characters, duplicated or missing words, bad line breaks, clipping, labels pointing to the wrong objects, misleading arrows, weak contrast, stretched images, or unreadably small text.
- Correct detected problems before delivery.

Primary output: a genuinely high-resolution PNG image.`,
      fieldsNote: `If suitable source visuals or diagrams are supplied, inspect and reuse them where they strengthen learning and remain accurate.`
    },

    reliefPack: {
      quickPrompt: 'Class relief pack',
      action: 'Create new',
      title: 'Relief pack',
      artifact: 'Teacher-ready relief lesson/resource',
      purpose: `Create an accurate, polished relief lesson that a competent general reliever can run with minimal specialist knowledge.`,
      task: `# ARTIFACT: RELIEF LESSON / RELIEF RESOURCE

Create a teacher-ready relief resource that is realistic for the stated time and class context.

## RELIEF DEFAULTS
- Make the learning goal explicit and achievable in the available time.
- Give the reliever short, ordered instructions and only the subject knowledge they genuinely need.
- Give students clear step-by-step directions that can be followed independently or with light support.
- Ensure every task is answerable from supplied material or clearly expected prior learning.
- Include answers/model responses where they materially help the reliever check progress.
- Incorporate device availability, behaviour reminders, collection instructions, room/resource constraints, and practical restrictions only when supplied or clearly relevant.
- For practical or safety-sensitive work, do not invent procedures; use only supported school/teacher instructions and verified safety information.

## QA
Check timing, workload, instructions, answers, spelling, print layout, and any safety-sensitive wording before delivery. Return the finished usable relief resource rather than advice about how to make one.`,
      fieldsNote: `If class notes, source activities, or school-specific instructions are attached, treat them as important local context and preserve them accurately.`
    },

    assessmentTeams: {
      quickPrompt: 'Assessment / Teams',
      action: 'Create new',
      title: 'Assessment / Teams',
      artifact: 'Assessment task / Teams package',
      purpose: `Create or improve an assessment resource, student instructions, or Teams package with especially strong evidence discipline around official requirements.`,
      task: `# ARTIFACT: ASSESSMENT / TEAMS RESOURCE

Create a clear, usable assessment-related resource.

## OFFICIAL ACCURACY
- If NCEA, NZQA, achievement standards, unit standards, credits, versions, grade criteria, moderation, submission requirements, or other official rules are involved, verify the exact current standard or official assessment source before making consequential claims.
- Never infer grade boundaries, credits, version numbers, submission rules, or criteria from memory or from a loosely related standard.
- Preserve supplied official wording accurately and distinguish teacher-created guidance from official requirements.
- If official information cannot be verified, state the limitation rather than guessing.

## RESOURCE QUALITY
- Distinguish student instructions, teacher guidance, evidence requirements, and marking support clearly.
- Make student instructions direct and understandable.
- Ensure any checklist or marking guide maps to the actual task and does not invent official criteria.
- Cross-check task wording, exemplars/models, and marking guidance for contradictions.
- Keep sources/verification notes available to the teacher without cluttering the student-facing task.

If a template is supplied, preserve its useful structure and return the finished usable resource.`,
      fieldsNote: `If an existing task, standard, assessment document, or template is attached, use it as the starting point but independently verify changing official claims.`
    },

    interactive: {
      quickPrompt: 'Interactive resource',
      action: 'Create new',
      title: 'Interactive resource',
      artifact: 'Interactive resource / HTML tool',
      purpose: `Create an accurate, intuitive interactive teaching resource or classroom tool and verify that its controls and calculations actually work.`,
      task: `# ARTIFACT: INTERACTIVE RESOURCE

Create the actual usable interactive resource where tools allow.

## INTERACTION DEFAULTS
- Make the primary workflow obvious by tap/click without requiring hover.
- Keep instructions visible and controls keyboard/touch accessible.
- If HTML is appropriate, prefer one self-contained file when practical and reliable.
- Avoid fake functionality, dead controls, inaccessible interactions, and placeholder outputs.
- Bound inputs and handle empty, zero, negative, invalid, and extreme values where relevant without showing NaN, Infinity, undefined, or broken states.

## FUNCTIONAL QA
- Exercise every control before delivery where tools permit.
- Test normal, boundary, and invalid inputs.
- Test reset/reload behaviour and rapid/repeated actions where relevant.
- Test narrow layouts and keyboard operation where practical.
- Check console errors and fix detected runtime problems.
- For calculations, compare expected and actual outputs against known expected values and independently verify the formula/logic.
- Never claim a control, calculation, browser, or device was tested unless it actually was.

Return the finished resource, not pseudocode or a feature list.`,
      fieldsNote: `If a previous resource, code, or example is attached, preserve useful behaviour but re-test changed and critical paths.`
    },

    custom: {
      quickPrompt: 'Teaching resource',
      action: 'Create new',
      title: 'Custom',
      artifact: 'Custom teaching resource',
      purpose: `Create or improve a polished, accurate teaching or school resource that matches the teacher's stated purpose.`,
      task: `# ARTIFACT: CUSTOM TEACHING RESOURCE

Create the requested teaching resource using the supplied context.

## DEFAULT STANDARD
- Infer the most suitable format from the stated goal unless a format is explicit.
- Apply the always-on truth/evidence, educational quality, accessibility, source-handling, and final QA rules.
- Preserve supplied source material and teacher intent.
- Research changing, official, specialised, technical, uncertain, safety-related, or consequential facts rather than guessing.
- Return a finished usable output rather than a rough outline unless the teacher asks for an outline.

If anything critical cannot be verified, state the limitation clearly and do not fabricate a complete-looking answer.`,
      fieldsNote: `Use the teacher's topic, purpose, source material, and extra information to infer the right output.`
    }
  };
})();
