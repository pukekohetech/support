(function(root, factory){
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.PHSAttachmentTools = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function(){
  const POSITIVE = /(attach|attachment|upload|file|document|paperclip|add\s*file)/i;
  const NEGATIVE = /(avatar|profile|account|logo|background|wallpaper)/i;
  const DOC_TYPES = /(pdf|docx?|pptx?|xlsx?|csv|text|plain|rtf|odt|ods|odp)/i;

  function scoreFileInput(meta){
    if (!meta || meta.disabled) return -Infinity;
    const accept = String(meta.accept || '');
    const identity = [meta.id, meta.name, meta.testid, meta.aria].filter(Boolean).join(' ');
    let score = 1;
    if (meta.multiple) score += 4;
    if (DOC_TYPES.test(accept)) score += 5;
    if (/image/i.test(accept)) score += 1;
    if (POSITIVE.test(identity)) score += 5;
    if (NEGATIVE.test(identity)) score -= 15;
    return score;
  }

  function inputMeta(input){
    return {
      disabled: !!input.disabled,
      multiple: !!input.multiple,
      accept: input.getAttribute?.('accept') || input.accept || '',
      id: input.id || '',
      name: input.getAttribute?.('name') || input.name || '',
      testid: input.getAttribute?.('data-testid') || '',
      aria: input.getAttribute?.('aria-label') || ''
    };
  }

  function findBestFileInput(doc){
    if (!doc || typeof doc.querySelectorAll !== 'function') return null;
    const inputs = [...doc.querySelectorAll('input[type="file"]')].filter(el => !el.disabled);
    if (!inputs.length) return null;
    inputs.sort((a,b) => scoreFileInput(inputMeta(b)) - scoreFileInput(inputMeta(a)));
    return scoreFileInput(inputMeta(inputs[0])) > -5 ? inputs[0] : null;
  }

  function buttonMeta(el){
    return {
      aria: el?.getAttribute?.('aria-label') || '',
      title: el?.getAttribute?.('title') || '',
      text: (el?.innerText || el?.textContent || '').trim()
    };
  }

  function buttonMatchesAttachment(meta){
    if (!meta) return false;
    const text = [meta.aria, meta.title, meta.text].filter(Boolean).join(' ');
    return POSITIVE.test(text) && !NEGATIVE.test(text);
  }

  function findAttachmentButton(doc){
    if (!doc || typeof doc.querySelectorAll !== 'function') return null;
    const candidates = [...doc.querySelectorAll('button,[role="button"],[aria-label],[title]')]
      .filter(el => buttonMatchesAttachment(buttonMeta(el)));
    if (!candidates.length) return null;
    candidates.sort((a,b) => {
      const ar = typeof a.getBoundingClientRect === 'function' ? a.getBoundingClientRect() : {bottom:0};
      const br = typeof b.getBoundingClientRect === 'function' ? b.getBoundingClientRect() : {bottom:0};
      return (br.bottom || 0) - (ar.bottom || 0);
    });
    return candidates[0];
  }

  function assignFiles(input, files){
    if (!input || !files || !files.length || typeof DataTransfer === 'undefined') return false;
    try {
      const dt = new DataTransfer();
      [...files].forEach(file => dt.items.add(file));
      input.files = dt.files;
      if (typeof Event !== 'undefined') {
        input.dispatchEvent(new Event('input', { bubbles:true }));
        input.dispatchEvent(new Event('change', { bubbles:true }));
      }
      return !!input.files && input.files.length === files.length;
    } catch (_) {
      return false;
    }
  }

  function openNativePicker(doc, onSelected){
    const input = findBestFileInput(doc);
    if (input) {
      if (typeof onSelected === 'function') {
        input.addEventListener('change', () => onSelected([...(input.files || [])]), { once:true });
      }
      try { input.click(); return { ok:true, mode:'input', input }; } catch (_) {}
    }
    const button = findAttachmentButton(doc);
    if (button) {
      try { button.click(); return { ok:true, mode:'button', button }; } catch (_) {}
    }
    return { ok:false, mode:'none' };
  }

  return {
    scoreFileInput,
    buttonMatchesAttachment,
    findBestFileInput,
    findAttachmentButton,
    assignFiles,
    openNativePicker
  };
});
