(() => {
  const root = window.PHSAI = window.PHSAI || {};

  function clean(value) {
    return String(value || '').trim();
  }

  const CHAT_TITLE_MAX = 40;

  function normaliseTitle(value) {
    return clean(value).replace(/\s+/g, ' ').replace(/\s*[\-–—]\s*$/g, '').trim();
  }

  function clipTitle(value, max = CHAT_TITLE_MAX) {
    const text = normaliseTitle(value);
    if (text.length <= max) return text;
    if (max <= 1) return text.slice(0, Math.max(0, max));
    let cut = text.slice(0, max - 1).trimEnd();
    const lastSpace = cut.lastIndexOf(' ');
    if (lastSpace >= Math.max(4, Math.floor(max * 0.55))) cut = cut.slice(0, lastSpace);
    cut = cut.replace(/\s*[\-–—]\s*$/g, '').trimEnd();
    return (cut || text.slice(0, max - 1)).slice(0, max - 1) + '…';
  }

  function shortYear(value) {
    const text = normaliseTitle(value);
    const range = text.match(/^Years?\s+(\d{1,2})\s*[–-]\s*(\d{1,2})$/i);
    if (range) return 'Y' + range[1] + '–' + range[2];
    const single = text.match(/^Year\s+(\d{1,2})$/i);
    if (single) return 'Y' + single[1];
    if (/staff|pld/i.test(text)) return 'Staff';
    if (/mixed|multi[- ]?level/i.test(text)) return 'Mixed';
    return clipTitle(text, 8);
  }

  function shortSubject(value) {
    const text = normaliseTitle(value).replace(/\s*\([^)]*\)\s*/g, ' ').trim();
    const lower = text.toLowerCase();
    if (!text) return '';
    if (/design and visual communication|design & visual communication|spatial and product design|\bdvc\b/i.test(text)) return 'DVC';
    if (/food.*technology|technology.*food/.test(lower)) return 'Food Tech';
    if (/digital.*technology|technology.*digital/.test(lower)) return 'Digital Tech';
    if (/multi[- ]?materials|hard technology|hard materials|materials technology/.test(lower)) return 'Tech';
    if (/engineering/.test(lower)) return 'Eng';
    if (/building|construction/.test(lower)) return 'Building';
    if (/catering/.test(lower)) return 'Catering';
    if (/mathematics|statistics/.test(lower)) return 'Maths';
    if (/social sciences|social studies/.test(lower)) return 'Social Sci';
    if (/health.*physical education|physical education.*health/.test(lower)) return 'HPE';
    if (/physical education/.test(lower)) return 'PE';
    if (/visual arts/.test(lower)) return 'Art';
    if (/learning languages/.test(lower)) return 'Languages';
    if (/technology/.test(lower)) return 'Tech';
    if (/english/.test(lower)) return 'English';
    if (/science/.test(lower)) return 'Science';
    if (/music/.test(lower)) return 'Music';
    if (/drama/.test(lower)) return 'Drama';
    if (/dance/.test(lower)) return 'Dance';
    if (/te reo māori|te reo maori/.test(lower)) return 'Te Reo Māori';
    return clipTitle(text, 14);
  }

  function titleSuffix(state) {
    if (state.mode === 'curriculum') {
      return ({ checkAlignment: 'Align', improveAlign: 'Review', completeDocument: 'Plan', createNewUnit: 'Unit', whatChanged: 'Update' })[state.workflow] || 'Curriculum';
    }
    return ({ powerpoint: 'PPT', worksheet: 'WS', infographic: 'Infographic', reliefPack: 'Relief', assessmentTeams: 'Assessment', interactive: 'Interactive', custom: 'Resource' })[state.workflow] || 'Resource';
  }

  function titleDetail(state) {
    const info = state.fields || {};
    let detail = normaliseTitle(info.topic);
    if (!detail && state.mode === 'curriculum') detail = normaliseTitle(curriculumSelection(state).focusLabel);
    if (!detail && state.mode === 'create' && state.workflow === 'custom') detail = normaliseTitle(state.workflowSpecific?.customOutput);
    const subject = normaliseTitle(state.mode === 'curriculum' ? curriculumSelection(state).subjectLabel || info.subject : info.subject);
    if (detail && subject && detail.toLowerCase().startsWith(subject.toLowerCase() + ' ')) detail = detail.slice(subject.length).trim();
    return detail.replace(/\band\b/gi, '&');
  }

  function shortChatTitle(state) {
    const override = normaliseTitle(state?.moreOptions?.chatTitle);
    if (override) return clipTitle(override);
    const info = state?.fields || {};
    const resolved = state?.mode === 'curriculum' ? curriculumSelection(state) : null;
    const year = shortYear(info.yearLevel);
    const subject = shortSubject(resolved?.subjectLabel || info.subject);
    const prefix = [year, subject].filter(Boolean).join(' ') || 'PHS';
    const suffix = titleSuffix(state || {});
    const detail = titleDetail(state || {});
    if (!detail) return clipTitle(prefix + ' – ' + suffix);
    const fixed = prefix.length + 3 + 1 + suffix.length;
    const available = Math.max(6, CHAT_TITLE_MAX - fixed);
    const detailShort = clipTitle(detail, available);
    return clipTitle(prefix + ' – ' + detailShort + ' ' + suffix);
  }

  function buildChatTitleHeader(state, workflow) {
    const title = shortChatTitle(state);
    const task = normaliseTitle(workflow?.title || titleSuffix(state));
    return task ? title + '\nTask: ' + task : title;
  }
  function bulletLines(items) {
    return items.filter(Boolean).map(item => `- ${item}`).join('\n');
  }

  function addIf(lines, label, value) {
    const cleaned = clean(value);
    if (cleaned) lines.push(`- ${label}: ${cleaned}`);
  }

  function describeQuickTweaks(state) {
    if (!state || state.mode !== 'create') return '';
    const selected = state.quickTweaks || {};
    const tweaks = (root.quickTweaks && root.quickTweaks[state.workflow]) || [];
    const lines = tweaks
      .filter(tweak => selected[tweak.id])
      .map(tweak => `- ${tweak.prompt}`);
    return lines.length ? `# QUICK TWEAKS\n\n${lines.join('\n')}` : '';
  }

  function describeMoreOptions(moreOptions) {
    const shared = root.sharedRules;
    const lines = [];
    if (!moreOptions) return '';

    Object.entries(shared.moreOptionsMap || {}).forEach(([key, text]) => {
      if (moreOptions[key]) lines.push(`- ${text}`);
    });
    addIf(lines, 'Specific learner needs', moreOptions.learnerNeeds);
    addIf(lines, 'Lesson / use length override', moreOptions.lessonOrUseLength);
    addIf(lines, 'Output scale / size', moreOptions.outputScale);
    addIf(lines, 'Visual direction', moreOptions.visualDirection);
    addIf(lines, 'Delivery environment', moreOptions.deliveryEnvironment);
    addIf(lines, 'Required features', moreOptions.requiredFeatures);
    addIf(lines, 'Features to avoid', moreOptions.avoidFeatures);

    return lines.length ? `# ADDITIONAL TEACHER PREFERENCES\n\n${lines.join('\n')}` : '';
  }

  function curriculumSelection(state) {
    const info = state.fields || {};
    if (typeof root.resolveCurriculumSelection === 'function') {
      return root.resolveCurriculumSelection(info);
    }
    return {
      subjectLabel: clean(info.subject),
      learningArea: clean(info.subject),
      focusLabel: clean(info.curriculumFocus),
      focusKind: clean(info.curriculumFocus) ? 'teacher-selected curriculum focus' : '',
      sourceTitle: '',
      sourceDate: '',
      sourceStatus: '',
      sourceUrl: '',
      mappingVerifiedOn: '',
      mappingNote: '',
      underpinningStrand: '',
      primaryFocus: clean(info.curriculumFocus),
      requiredCompanions: [],
      programmeRequirements: [],
      conditionalRequirements: [],
      isCustomFocus: false,
      isCustomSubject: false,
      isSenior: false
    };
  }

  function curriculumContext(state, workflow) {
    const info = state.fields || {};
    const resolved = curriculumSelection(state);
    const contextLines = [
      `- Year level: ${clean(info.yearLevel)}`,
      `- Intended teaching year: ${clean(info.intendedTeachingYear)}`,
      `- Subject / learning area: ${clean(resolved.subjectLabel) || clean(info.subject)}`
    ];
    if (clean(resolved.learningArea) && clean(resolved.learningArea) !== clean(resolved.subjectLabel)) {
      contextLines.push(`- Mapped national learning area: ${clean(resolved.learningArea)}`);
    }
    if (clean(resolved.focusLabel)) contextLines.push(`- Curriculum focus / strand: ${clean(resolved.focusLabel)}`);
    if (clean(info.topic)) contextLines.push(`- Unit / topic: ${clean(info.topic)}`);
    if (clean(info.extraInfo)) contextLines.push(`- Extra information: ${clean(info.extraInfo)}`);

    const quickMap = [
      '# CURRENT REQUEST — QUICK MAP',
      `Prompt: ${workflow.quickPrompt}`,
      `Action: ${workflow.action}`,
      `Year: ${clean(info.yearLevel)}`
    ];
    if (clean(info.topic)) quickMap.push(`Topic: ${clean(info.topic)}`);
    quickMap.push(
      'Source handling: Smart — use supplied material; verify and research whenever reliability requires it',
      `PHS branding: ${state.moreOptions?.phsBranding ? 'ON' : 'OFF'}`
    );

    return [
      ...quickMap,
      '',
      '# TEACHER TASK',
      `Workflow: ${workflow.title}`,
      '',
      '# PROVIDED CONTEXT',
      contextLines.join('\n'),
      '',
      '# PURPOSE',
      workflow.purpose,
      '',
      '# IMPORTANT SOURCE NOTE',
      workflow.fieldsNote
    ].join('\n');
  }

  function curriculumReference(state) {
    const resolved = curriculumSelection(state);
    const lines = [
      '# BUILDER CURRICULUM REFERENCE — VERIFY BEFORE RELYING ON IT',
      '',
      '- This is a source-aware starting reference captured by the PHS AI Assistant. It is NOT authority for current curriculum status by itself.',
      `- Selected subject / course: ${clean(resolved.subjectLabel) || 'Not specified'}`,
      `- Mapped learning area: ${clean(resolved.learningArea) || 'To verify'}`
    ];
    if (clean(resolved.focusLabel)) lines.push(`- Selected curriculum focus / strand: ${clean(resolved.focusLabel)}`);
    if (clean(resolved.focusKind)) lines.push(`- Focus classification: ${clean(resolved.focusKind)}`);
    if (clean(resolved.sourceTitle)) lines.push(`- Mapped source: ${clean(resolved.sourceTitle)}`);
    if (clean(resolved.sourceDate)) lines.push(`- Source date / release: ${clean(resolved.sourceDate)}`);
    if (clean(resolved.sourceStatus)) lines.push(`- Recorded source status: ${clean(resolved.sourceStatus)}`);
    if (clean(resolved.sourceUrl)) lines.push(`- Source URL: ${clean(resolved.sourceUrl)}`);
    if (clean(resolved.mappingVerifiedOn)) lines.push(`- Builder mapping last checked: ${clean(resolved.mappingVerifiedOn)}`);
    if (clean(resolved.mappingNote)) lines.push(`- Mapping note: ${clean(resolved.mappingNote)}`);
    if (clean(resolved.underpinningStrand)) lines.push(`- Underpinning Technology strand to include: ${clean(resolved.underpinningStrand)}`);
    if (Array.isArray(resolved.requiredCompanions) && resolved.requiredCompanions.length) lines.push(`- Pre-mapped required companions: ${resolved.requiredCompanions.join(' | ')}`);
    if (Array.isArray(resolved.programmeRequirements) && resolved.programmeRequirements.length) lines.push(`- Pre-mapped programme-level requirements: ${resolved.programmeRequirements.join(' | ')}`);
    if (Array.isArray(resolved.conditionalRequirements) && resolved.conditionalRequirements.length) lines.push(`- Pre-mapped conditional requirements: ${resolved.conditionalRequirements.join(' | ')}`);
    return lines.join('\n');
  }

  function curriculumVerificationGate(state) {
    const resolved = curriculumSelection(state);
    const customNote = resolved.isCustomFocus || resolved.isCustomSubject
      ? '\n- The teacher has selected or defined a local/custom scope. Treat it as teacher intent, not as proof of an official curriculum label.'
      : '';
    return `# CURRICULUM VERIFICATION GATE — MUST RUN BEFORE PROCEEDING

This gate overrides the normal complete-now execution contract below whenever a material curriculum mismatch, unresolved current-status issue, or consequential verification gap is found.

Before analysing, aligning, improving, completing, or creating curriculum material:
1. Identify the selected year level, intended teaching year, subject/learning area, and curriculum focus/strand.
2. Check the most current authoritative New Zealand source available for that learning area and year level. Prefer the current Ministry of Education / Tāhūrangi curriculum source. If the mapped or supplied source is proposed, transitional, awaiting commencement, or expected to be replaced, check whether a New Zealand Gazette National Curriculum Statement or a newer official Ministry release has superseded it. For Years 11–13, NCEA, or assessment-standard claims, also verify the current senior curriculum and NZQA source where relevant.
3. Confirm the current source version/status/date, that it applies to the selected year and intended teaching year, the exact strand/focus naming and structure, and any implementation or transition requirements.
4. Compare that current authoritative evidence with the BUILDER CURRICULUM REFERENCE above and with any curriculum document or source supplied by the teacher.
5. If the sources are materially consistent and current, continue with the requested task without adding an unnecessary confirmation step.
6. If there is a mismatch, newer curriculum release, changed strand or focus structure or wording, changed implementation requirement, unclear source status, or another important development that could materially affect the result, STOP before completing the task. Briefly explain the mismatch/development, identify the relevant source/version/date, and ask the teacher which source, version, or scope they want used before proceeding.
7. Never silently substitute one curriculum version, strand, or framework for another.
8. A teacher-defined/local focus is a requested scope, not automatically an official curriculum strand. Verify how it relates to the current official curriculum, and STOP and ask the teacher if the relationship is ambiguous or materially different.
9. If you cannot access or cannot verify authoritative current sources and currentness matters to the judgement, say so and ask the teacher to upload or approve the curriculum source before making consequential alignment claims.
10. Do not invent an official strand, curriculum statement, implementation date, source, or requirement. Do not proceed on model memory alone when current verification is required.${customNote}`;
  }

  function curriculumStructureCheck(state) {
    const resolved = curriculumSelection(state);
    const primary = clean(resolved.primaryFocus) || clean(resolved.focusLabel) || 'Determine from the verified current curriculum and teacher intent';
    const required = Array.isArray(resolved.requiredCompanions) ? resolved.requiredCompanions : [];
    const programme = Array.isArray(resolved.programmeRequirements) ? resolved.programmeRequirements : [];
    const conditional = Array.isArray(resolved.conditionalRequirements) ? resolved.conditionalRequirements : [];

    const lines = [
      '# CURRICULUM STRUCTURE CHECK — REQUIRED AFTER VERIFICATION',
      '',
      'After the verification gate and before making alignment judgements, determine how the CURRENT verified curriculum structure applies to this task. The builder notes below are starting expectations only; authoritative current curriculum evidence overrides them.',
      '',
      `- Primary focus: ${primary}`,
      `- Required companions: ${required.length ? required.join(' | ') : 'None pre-mapped. Check the verified curriculum for underpinning strands, processes, practices, concepts, modes, or other elements that must accompany the selected focus.'}`,
      `- Programme-level requirements: ${programme.length ? programme.join(' | ') : 'None pre-mapped. Check whether the curriculum specifies wider year/course coverage that should not be misreported as a gap in this individual unit.'}`,
      `- Conditional requirements: ${conditional.length ? conditional.join(' | ') : 'None pre-mapped. Ask only if the verified curriculum shows that a consequential requirement depends on missing information.'}`,
      '',
      'Rules:',
      '1. Include verified required companions automatically in the alignment; do not make the teacher select them separately.',
      '2. Keep programme-level requirements separate from unit-level requirements. Do not mark an individual unit deficient for learning intentionally delivered elsewhere in the wider programme.',
      '3. If a conditional requirement cannot be resolved from the teacher context or authoritative source, STOP and ask the minimum necessary question before proceeding.',
      '4. If current verification changes any pre-mapped companion, programme-level, or conditional rule, STOP, explain the material change briefly, and ask the teacher which current source/scope to use before completing the task.',
      '5. Never invent a companion requirement merely because two curriculum areas are related.'
    ];
    return lines.join('\n');
  }

  function resourceContext(state, workflow) {
    const info = state.fields || {};
    const lines = [
      `- Year level: ${clean(info.yearLevel)}`,
      `- Subject / topic area: ${clean(info.subject)}`,
      `- Topic: ${clean(info.topic)}`,
      `- Learning goal / purpose: ${clean(info.learningGoal)}`
    ];
    if (clean(info.extraInfo)) lines.push(`- Extra information: ${clean(info.extraInfo)}`);

    Object.entries(state.workflowSpecific || {}).forEach(([key, value]) => {
      if (clean(value) && value !== 'Not specified') {
        const label = key
          .replace(/([A-Z])/g, ' $1')
          .replace(/^./, m => m.toUpperCase());
        lines.push(`- ${label}: ${clean(value)}`);
      }
    });

    const outputLabel = workflow.artifact || workflow.title;

    return [
      '# CURRENT REQUEST — QUICK MAP',
      `Prompt: ${workflow.quickPrompt}`,
      `Action: ${workflow.action}`,
      `Year: ${clean(info.yearLevel)}`,
      `Topic: ${clean(info.topic)}`,
      'Source handling: Smart — use supplied material; verify and research whenever reliability requires it',
      `PHS branding: ${state.moreOptions?.phsBranding ? 'ON' : 'OFF'}`,
      `Output: ${outputLabel}`,
      '',
      '# TEACHER TASK',
      `Artifact: ${workflow.title}`,
      '',
      '# PROVIDED CONTEXT',
      lines.join('\n'),
      '',
      '# PURPOSE',
      workflow.purpose,
      '',
      '# IMPORTANT SOURCE NOTE',
      workflow.fieldsNote
    ].join('\n');
  }

  function curriculumScopeRule(state) {
    const resolved = curriculumSelection(state);
    const focus = clean(resolved.focusLabel);
    if (!focus) return '';
    const lines = [
      '# CURRICULUM ALIGNMENT SCOPE',
      '',
      `- Scope the alignment review primarily to the selected curriculum focus / strand: ${focus}.`,
      '- Treat this unit as one part of a wider programme. Do not report other strands, disciplines, or sub-areas as missing merely because they are intentionally taught elsewhere.',
      '- Only identify broader programme-coverage gaps when the teacher explicitly asks for a whole-programme audit.',
      '- Where learning is integrated across more than one strand, acknowledge relevant connections without turning every connected strand into a requirement for this unit.'
    ];
    if (resolved.isCustomFocus) {
      lines.push('- This focus is teacher-defined. Use it as the requested review scope, but do not treat it as an official curriculum strand unless current authoritative evidence verifies that status.');
    }
    if (clean(resolved.underpinningStrand)) {
      lines.push(`- For Technology, ${clean(resolved.underpinningStrand)} is the underpinning strand and should be considered through the selected discipline-specific strand. Do not mistake the other Technology discipline-specific strands for requirements of this individual unit.`);
    }
    return lines.join('\n');
  }

  function generateCurriculumPrompt(state) {
    const wf = root.curriculumPrompts[state.workflow];
    if (!wf) throw new Error('Unknown curriculum workflow.');
    const sections = [
      curriculumContext(state, wf),
      '',
      curriculumReference(state),
      '',
      curriculumVerificationGate(state),
      '',
      curriculumStructureCheck(state),
      '',
      root.sharedRules.executionContract,
      '',
      root.sharedRules.truthAndEvidence,
      '',
      root.sharedRules.educationalQuality,
      ''
    ];
    const scopeRule = curriculumScopeRule(state);
    if (scopeRule) sections.push(scopeRule, '');
    sections.push(
      '# CURRICULUM-SPECIFIC RULES\n\n- Teacher-supplied material is evidence of current practice, not proof of current curriculum requirements.\n- Verify applicable curriculum claims with current official Ministry of Education / Tāhūrangi sources before judging alignment.\n- Distinguish CURRENT, TRANSITIONAL, FUTURE / DRAFT, or NO LONGER APPLICABLE material explicitly where relevant.\n- Preserve useful teacher intent and local context.\n- Do not invent curriculum statements, progress outcomes, achievement objectives, local curriculum expectations, or school-specific requirements.\n- Provide a concise verification/source note for consequential curriculum claims so the teacher can check what the judgement was based on.',
      '',
      wf.task,
      ''
    );
    const extra = describeMoreOptions(state.moreOptions);
    if (extra) sections.push(extra, '');
    sections.push(root.sharedRules.smartSource, '', root.sharedRules.nzContext, '', root.sharedRules.finalQualityGate, '', root.sharedRules.advancedQA);
    return buildChatTitleHeader(state, wf) + '\n\n' + sections.join('\n');
  }

  function generateResourcePrompt(state) {
    const wf = root.resourcePrompts[state.workflow];
    if (!wf) throw new Error('Unknown resource workflow.');
    const sections = [
      resourceContext(state, wf),
      '',
      root.sharedRules.executionContract,
      '',
      root.sharedRules.truthAndEvidence,
      '',
      root.sharedRules.educationalQuality,
      '',
      wf.task,
      ''
    ];
    const quick = describeQuickTweaks(state);
    if (quick) sections.push(quick, '');
    const extra = describeMoreOptions(state.moreOptions);
    if (extra) sections.push(extra, '');
    sections.push(root.sharedRules.smartSource, '', root.sharedRules.nzContext, '', root.sharedRules.finalQualityGate, '', root.sharedRules.advancedQA);
    return buildChatTitleHeader(state, wf) + '\n\n' + sections.join('\n');
  }

  root.promptEngine = {
    chatTitle: shortChatTitle,
    generate(state) {
      if (!state || !state.mode) throw new Error('No prompt state was provided.');
      return state.mode === 'curriculum' ? generateCurriculumPrompt(state) : generateResourcePrompt(state);
    }
  };
})();
