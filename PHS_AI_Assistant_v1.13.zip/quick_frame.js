(() => {
  const root = window.PHSAI || {};
  if (!root.promptEngine || !root.modeConfig) {
    document.getElementById('app').textContent = 'PHS AI Assistant could not load its prompt engine.';
    return;
  }

  const STORAGE_KEY = 'phsAiAssistantPrefs';
  const PHS_MANUAL_LINKS = {
    shield: 'https://github.com/pukekohetech/support/blob/main/Shield.webp',
    lessonPlan: 'https://github.com/pukekohetech/support/blob/main/lesson_plan_template_PHS.docx',
    juniorUnitPlan: 'https://github.com/pukekohetech/support/blob/main/Junior_Curriculum_Unit_Plan_Cover_Sheet.docx'
  };
  const PHS_BUILTIN_FILES = [
    { id: 'shield', name: 'Shield.webp', path: 'Shield.webp', mime: 'image/webp', label: 'Official PHS shield', kind: 'WEBP image' },
    { id: 'lesson-plan', name: 'lesson_plan_template_PHS.docx', path: 'lesson_plan_template_PHS.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', label: 'PHS lesson plan template', kind: 'Word template' },
    { id: 'junior-unit-plan', name: 'Junior_Curriculum_Unit_Plan_Cover_Sheet.docx', path: 'Junior_Curriculum_Unit_Plan_Cover_Sheet.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', label: 'Junior curriculum unit plan', kind: 'Word template' }
  ];
  const PHSFileData = globalThis.PHSFileData || null;
  const builtinFileCache = new Map();
  let stagedFileCounter = 0;
  const params = new URLSearchParams(location.search);
  let platform = params.get('platform') || 'AI chat';

  const state = {
    mode: root.defaults.mode,
    selectedWorkflowByMode: {
      curriculum: root.defaults.curriculumWorkflow,
      create: root.defaults.resourceWorkflow
    },
    fields: {
      yearLevel: root.defaults.yearLevel,
      intendedTeachingYear: root.defaults.intendedTeachingYear,
      subject: '',
      customSubject: '',
      curriculumFocus: '',
      customCurriculumFocus: '',
      topic: '',
      learningGoal: '',
      extraInfo: ''
    },
    workflowSpecific: {},
    moreOptions: {},
    moreOptionsOpen: false,
    validationErrors: {},
    status: {
      text: 'Choose a workflow, add a little context, and insert the prompt. Nothing is sent automatically.',
      kind: ''
    },
    lastPrompt: '',
    showPreview: false,
    toolsOpen: false,
    fileNote: 'No files added through PHS AI yet.',
    stagedFiles: []
  };

  const app = document.getElementById('app');

  function storageGet() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get([STORAGE_KEY], result => resolve(result[STORAGE_KEY] || null));
      } catch (_) { resolve(null); }
    });
  }

  function storageSetPrefs() {
    const prefs = {
      mode: state.mode,
      selectedWorkflowByMode: state.selectedWorkflowByMode,
      yearLevel: state.fields.yearLevel,
      intendedTeachingYear: state.fields.intendedTeachingYear
    };
    try { chrome.storage.local.set({ [STORAGE_KEY]: prefs }); } catch (_) {}
  }

  function storageClear() {
    return new Promise(resolve => {
      try { chrome.storage.local.remove([STORAGE_KEY], () => resolve()); }
      catch (_) { resolve(); }
    });
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function activeWorkflowId() { return state.selectedWorkflowByMode[state.mode]; }

  function visibleFields() {
    const baseFields = root.fieldsForWorkflow
      ? root.fieldsForWorkflow(state.mode, activeWorkflowId())
      : [...root.modeConfig[state.mode].fields];
    if (state.mode === 'create') {
      const extras = root.resourceExtraFields[activeWorkflowId()] || [];
      return [...baseFields, ...extras];
    }

    return baseFields
      .filter(field => {
        if (field.visibleWhen === 'customSubject') {
          return state.fields.subject === root.curriculumCustomSubjectValue;
        }
        if (field.visibleWhen === 'customCurriculumFocus') {
          return state.fields.curriculumFocus === root.curriculumCustomFocusValue;
        }
        return true;
      })
      .map(field => {
        if (field.id === 'customSubject') {
          return { ...field, required: state.fields.subject === root.curriculumCustomSubjectValue };
        }
        if (field.id === 'customCurriculumFocus') {
          return { ...field, required: state.fields.curriculumFocus === root.curriculumCustomFocusValue };
        }
        return field;
      });
  }

  function fieldValue(fieldId, defaultValue = '') {
    if (Object.prototype.hasOwnProperty.call(state.fields, fieldId)) return state.fields[fieldId];
    if (Object.prototype.hasOwnProperty.call(state.workflowSpecific, fieldId)) return state.workflowSpecific[fieldId];
    return defaultValue;
  }

  function setStatus(text, kind = '') {
    state.status = { text, kind };
    render();
  }

  function setMode(mode) {
    state.mode = mode;
    state.validationErrors = {};
    state.status = { text: 'Choose a workflow, add a little context, and insert the prompt. Nothing is sent automatically.', kind: '' };
    state.showPreview = false;
    state.lastPrompt = '';
    storageSetPrefs();
    render();
  }

  function setWorkflow(id) {
    state.selectedWorkflowByMode[state.mode] = id;
    state.validationErrors = {};
    state.status = { text: 'Workflow selected. Add the essential details and insert the prompt.', kind: '' };
    state.showPreview = false;
    state.lastPrompt = '';
    if (state.mode === 'create') {
      const extras = root.resourceExtraFields[id] || [];
      const nextSpecific = {};
      extras.forEach(field => {
        const existing = state.workflowSpecific[field.id];
        nextSpecific[field.id] = existing || field.defaultValue || '';
      });
      state.workflowSpecific = nextSpecific;
    }
    storageSetPrefs();
    render();
  }

  function setField(fieldId, value) {
    const isBase = root.modeConfig[state.mode].fields.some(field => field.id === fieldId);
    if (isBase) state.fields[fieldId] = value;
    else state.workflowSpecific[fieldId] = value;

    if (state.mode === 'curriculum') {
      if (fieldId === 'subject') {
        state.fields.curriculumFocus = '';
        state.fields.customCurriculumFocus = '';
        if (value !== root.curriculumCustomSubjectValue) state.fields.customSubject = '';
      }
      if (fieldId === 'curriculumFocus' && value !== root.curriculumCustomFocusValue) {
        state.fields.customCurriculumFocus = '';
      }
      if (fieldId === 'yearLevel' || fieldId === 'intendedTeachingYear') {
        const resolver = root.curriculumFocusOptions;
        if (typeof resolver === 'function' && state.fields.curriculumFocus) {
          const valid = resolver(state.fields.subject, state.fields.yearLevel, state.fields.intendedTeachingYear)
            .map(option => typeof option === 'object' ? option.value : option);
          if (!valid.includes(state.fields.curriculumFocus)) {
            state.fields.curriculumFocus = '';
            state.fields.customCurriculumFocus = '';
          }
        }
      }
    }

    if (fieldId === 'yearLevel' || fieldId === 'intendedTeachingYear') storageSetPrefs();
    if (state.validationErrors[fieldId]) delete state.validationErrors[fieldId];
    const needsRender = state.mode === 'curriculum' && typeof root.curriculumFieldChangeNeedsRender === 'function'
      ? root.curriculumFieldChangeNeedsRender(fieldId)
      : false;
    if (needsRender) render();
  }

  function setMoreOption(fieldId, value) { state.moreOptions[fieldId] = value; }

  function validate() {
    const errors = {};
    visibleFields().forEach(field => {
      if (!field.required) return;
      const value = String(fieldValue(field.id, field.defaultValue || '') || '').trim();
      if (!value) errors[field.id] = 'This field is required.';
    });
    state.validationErrors = errors;
    return !Object.keys(errors).length;
  }

  function promptState() {
    return {
      mode: state.mode,
      workflow: activeWorkflowId(),
      fields: { ...state.fields },
      workflowSpecific: { ...state.workflowSpecific },
      moreOptions: { ...state.moreOptions }
    };
  }

  function generatePrompt() {
    const prompt = root.promptEngine.generate(promptState());
    state.lastPrompt = prompt;
    return prompt;
  }

  function post(type, extra = {}) {
    window.parent.postMessage({ type, ...extra }, '*');
  }

  function handleInsert() {
    if (!validate()) {
      setStatus('Please complete the required fields first.', 'bad');
      return;
    }
    const prompt = generatePrompt();
    state.showPreview = false;
    post('PHS_QUICK_INSERT', { prompt });
    setStatus(`Handing the prompt to ${platform}. Nothing will be sent automatically.`, '');
  }

  function handleCopy() {
    if (!validate()) {
      setStatus('Please complete the required fields first.', 'bad');
      return;
    }
    const prompt = state.lastPrompt || generatePrompt();
    state.showPreview = true;
    render();
    post('PHS_QUICK_COPY', { prompt });
  }

  async function handleResetPrefs() {
    await storageClear();
    state.mode = root.defaults.mode;
    state.selectedWorkflowByMode = {
      curriculum: root.defaults.curriculumWorkflow,
      create: root.defaults.resourceWorkflow
    };
    state.fields.yearLevel = root.defaults.yearLevel;
    state.fields.intendedTeachingYear = root.defaults.intendedTeachingYear;
    state.fields.subject = '';
    state.fields.customSubject = '';
    state.fields.curriculumFocus = '';
    state.fields.customCurriculumFocus = '';
    state.fields.topic = '';
    state.fields.extraInfo = '';
    state.workflowSpecific = {};
    state.moreOptions = {};
    state.moreOptionsOpen = false;
    setStatus('Saved preferences were reset.', 'good');
  }

  function renderField(field) {
    const requiredClass = field.required ? ' phs-ai-required' : '';
    const error = state.validationErrors[field.id] ? `<div class="phs-ai-error">${escapeHtml(state.validationErrors[field.id])}</div>` : '';
    const value = fieldValue(field.id, field.defaultValue || '');
    const helpText = field.helpResolver && typeof root[field.helpResolver] === 'function'
      ? root[field.helpResolver](state.fields.subject, state.fields.yearLevel, state.fields.intendedTeachingYear)
      : field.help;
    const help = helpText ? `<div class="phs-ai-help">${escapeHtml(helpText)}</div>` : '';

    if (field.type === 'select') {
      let options = field.options;
      if (field.optionsResolver && typeof root[field.optionsResolver] === 'function') {
        options = root[field.optionsResolver](state.fields.subject, state.fields.yearLevel, state.fields.intendedTeachingYear);
      } else if (field.optionsSource) {
        options = root[field.optionsSource];
      }
      const optionsHtml = (options || []).map(option => {
        const optionValue = typeof option === 'object' && option !== null ? option.value : option;
        const optionLabel = typeof option === 'object' && option !== null ? option.label : option;
        const selected = String(optionValue) === String(value) ? ' selected' : '';
        return `<option value="${escapeHtml(optionValue)}"${selected}>${escapeHtml(optionLabel)}</option>`;
      }).join('');
      return `<div class="phs-ai-field"><label class="phs-ai-label${requiredClass}" for="field-${escapeHtml(field.id)}">${escapeHtml(field.label)}</label><select class="phs-ai-select" id="field-${escapeHtml(field.id)}" data-field-id="${escapeHtml(field.id)}">${optionsHtml}</select>${help}${error}</div>`;
    }

    if (field.type === 'textarea') {
      return `<div class="phs-ai-field"><label class="phs-ai-label${requiredClass}" for="field-${escapeHtml(field.id)}">${escapeHtml(field.label)}</label><textarea class="phs-ai-textarea" id="field-${escapeHtml(field.id)}" data-field-id="${escapeHtml(field.id)}" placeholder="${escapeHtml(field.placeholder || '')}">${escapeHtml(value)}</textarea>${help}${error}</div>`;
    }

    return `<div class="phs-ai-field"><label class="phs-ai-label${requiredClass}" for="field-${escapeHtml(field.id)}">${escapeHtml(field.label)}</label><input class="phs-ai-input" id="field-${escapeHtml(field.id)}" data-field-id="${escapeHtml(field.id)}" value="${escapeHtml(value)}" placeholder="${escapeHtml(field.placeholder || '')}">${help}${error}</div>`;
  }

  function runtimeUrl(filePath) {
    try { return chrome.runtime.getURL(filePath); } catch (_) { return filePath; }
  }

  function formatBytes(bytes) {
    const value = Number(bytes) || 0;
    if (value < 1024) return value + ' B';
    if (value < 1024 * 1024) return (value / 1024).toFixed(value < 10240 ? 1 : 0) + ' KB';
    return (value / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function preloadBuiltInFiles() {
    PHS_BUILTIN_FILES.forEach(item => {
      if (builtinFileCache.has(item.id)) return;
      try {
        if (!PHSFileData?.isReady?.()) return;
        builtinFileCache.set(item.id, PHSFileData.makeFile(item.id, item.name));
      } catch (_) {}
    });
  }

  function downloadFileObject(file, downloadName) {
    if (!file) return false;
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url;
    link.download = downloadName || file.name || 'PHS-file';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    return true;
  }

  function downloadBuiltInFile(id) {
    preloadBuiltInFiles();
    const item = PHS_BUILTIN_FILES.find(file => file.id === id);
    const file = builtinFileCache.get(id) || null;
    if (!item || !file) {
      setStatus('That PHS file is unavailable in this extension package. Use the GitHub fallback link.', 'bad');
      return;
    }
    downloadFileObject(file, item.name);
    setStatus(`${item.name} downloaded.`, 'good');
  }

  function downloadBuiltInBundle() {
    try {
      if (!PHSFileData?.isReady?.()) throw new Error('PHS file data unavailable');
      const file = PHSFileData.makeFile('working-files-zip', 'PHS_Working_Files.zip');
      downloadFileObject(file, 'PHS_Working_Files.zip');
      setStatus('PHS working files ZIP downloaded.', 'good');
    } catch (_) {
      setStatus('The PHS working files ZIP is unavailable in this extension package.', 'bad');
    }
  }

  function addStagedFiles(fileList) {
    const incoming = Array.from(fileList || []);
    if (!incoming.length) return;
    const seen = new Set(state.stagedFiles.map(entry => entry.file.name + '|' + entry.file.size + '|' + entry.file.lastModified));
    incoming.forEach(file => {
      const key = file.name + '|' + file.size + '|' + file.lastModified;
      if (seen.has(key)) return;
      seen.add(key);
      stagedFileCounter += 1;
      state.stagedFiles.push({ id: 'local-' + stagedFileCounter, file });
    });
    state.stagedFiles = state.stagedFiles.slice(-20);
    state.fileNote = state.stagedFiles.length + ' personal file' + (state.stagedFiles.length === 1 ? '' : 's') + ' staged for this session. Drag them to the AI attachment area or download them again if needed.';
    render();
  }

  function downloadStagedFile(id) {
    const entry = state.stagedFiles.find(item => item.id === id);
    if (!entry) return;
    downloadFileObject(entry.file, entry.file.name);
  }

  function removeStagedFile(id) {
    state.stagedFiles = state.stagedFiles.filter(item => item.id !== id);
    state.fileNote = state.stagedFiles.length
      ? state.stagedFiles.length + ' personal file' + (state.stagedFiles.length === 1 ? '' : 's') + ' staged for this session.'
      : 'No personal files staged. The three official PHS working files remain available below.';
    render();
  }

  function addDragPayload(event, file, url, name, mime) {
    const dataTransfer = event.dataTransfer;
    if (!dataTransfer) return;
    dataTransfer.effectAllowed = 'copy';
    if (file && dataTransfer.items && typeof dataTransfer.items.add === 'function') {
      try { dataTransfer.items.add(file); } catch (_) {}
    }
    if (url) {
      try { dataTransfer.setData('DownloadURL', (mime || file?.type || 'application/octet-stream') + ':' + (name || file?.name || 'file') + ':' + url); } catch (_) {}
      try { dataTransfer.setData('text/uri-list', url); } catch (_) {}
    }
    try { dataTransfer.setData('text/plain', name || file?.name || 'PHS file'); } catch (_) {}
  }

  function handleFileDragStart(event) {
    const card = event.currentTarget;
    const source = card.getAttribute('data-drag-source');
    const id = card.getAttribute('data-file-id');
    if (source === 'builtin') {
      const item = PHS_BUILTIN_FILES.find(file => file.id === id);
      if (!item) return;
      preloadBuiltInFiles();
      const file = builtinFileCache.get(id) || null;
      if (!file) return;
      const objectUrl = URL.createObjectURL(file);
      addDragPayload(event, file, objectUrl, item.name, item.mime);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      return;
    }
    const entry = state.stagedFiles.find(item => item.id === id);
    if (!entry) return;
    const objectUrl = URL.createObjectURL(entry.file);
    addDragPayload(event, entry.file, objectUrl, entry.file.name, entry.file.type);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
  }

  function renderBuiltInFileCard(item) {
    const ready = builtinFileCache.has(item.id);
    const stateText = ready ? 'Ready' : 'Unavailable';
    const stateColour = ready ? '#215f49' : '#8a2f3d';
    return `<article draggable="${ready ? 'true' : 'false'}" data-drag-source="builtin" data-file-id="${escapeHtml(item.id)}" style="border:1px solid #dfe7e3;border-radius:10px;background:#fff;padding:8px;display:grid;gap:5px;cursor:${ready ? 'grab' : 'default'};">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">
        <div style="font-size:10.5px;font-weight:800;color:#2f3d38;overflow-wrap:anywhere;">${escapeHtml(item.name)}</div>
        <div style="font-size:9px;font-weight:800;color:${stateColour};white-space:nowrap;">${stateText}</div>
      </div>
      <div style="font-size:9.5px;color:#6a7873;">${escapeHtml(item.label)} · ${escapeHtml(item.kind)}</div>
      <button class="phs-ai-secondary" type="button" data-download-builtin="${escapeHtml(item.id)}" ${ready ? '' : 'disabled'} style="min-height:30px;padding:5px 8px;font-size:10px;">Download</button>
    </article>`;
  }

  function renderStagedFileCard(entry) {
    return `<article draggable="true" data-drag-source="staged" data-file-id="${escapeHtml(entry.id)}" style="border:1px solid #dfe7e3;border-radius:10px;background:#fff;padding:8px;display:grid;gap:5px;cursor:grab;">
      <div style="font-size:10.5px;font-weight:800;color:#2f3d38;overflow-wrap:anywhere;">${escapeHtml(entry.file.name)}</div>
      <div style="font-size:9.5px;color:#6a7873;">My file · ${escapeHtml(formatBytes(entry.file.size))}</div>
      <div style="display:grid;grid-template-columns:1fr auto;gap:5px;">
        <button class="phs-ai-secondary" type="button" data-download-staged="${escapeHtml(entry.id)}" style="min-height:30px;padding:5px 8px;font-size:10px;">Download</button>
        <button class="phs-ai-secondary" type="button" data-remove-staged="${escapeHtml(entry.id)}" style="min-height:30px;padding:5px 8px;font-size:10px;">Remove</button>
      </div>
    </article>`;
  }

  function renderFileShelf() {
    const staged = state.stagedFiles.length
      ? state.stagedFiles.map(renderStagedFileCard).join('')
      : '<div style="font-size:10px;color:#75827e;padding:3px 1px;">No personal files staged yet.</div>';
    return `<div id="phs-file-shelf" style="display:grid;gap:8px;">
      <div style="font-size:10.5px;font-weight:800;color:#3a4a45;">PHS working files</div>
      <div style="font-size:9.8px;color:#62726c;line-height:1.4;">Drag a card toward the AI attachment area. Browser/site support varies, so <strong>Download</strong> is the reliable fallback.</div>
      <div style="display:grid;grid-template-columns:1fr;gap:6px;">${PHS_BUILTIN_FILES.map(renderBuiltInFileCard).join('')}</div>
      <button class="phs-ai-secondary" type="button" data-download-bundle="working-files-zip" ${PHSFileData?.isReady?.() ? '' : 'disabled'} style="min-height:34px;padding:6px 8px;font-size:10.5px;">Download all PHS files</button>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:2px;">
        <div style="font-size:10.5px;font-weight:800;color:#3a4a45;">My files — this session</div>
        <button class="phs-ai-secondary" id="add-my-files" type="button" style="min-height:32px;padding:5px 8px;font-size:10px;">Add my files</button>
      </div>
      <input id="staged-file-picker" type="file" multiple hidden>
      <div style="display:grid;grid-template-columns:1fr;gap:6px;">${staged}</div>
    </div>`;
  }

  function renderMoreOptions() {
    const openClass = state.moreOptionsOpen ? ' open' : '';
    const checkboxItems = root.moreOptionsConfig.filter(item => item.type === 'checkbox');
    const otherItems = root.moreOptionsConfig.filter(item => item.type !== 'checkbox');
    const checkboxHtml = checkboxItems.map(item => `<label class="phs-ai-checkbox"><input type="checkbox" data-option-id="${escapeHtml(item.id)}" ${state.moreOptions[item.id] ? 'checked' : ''}><span>${escapeHtml(item.label)}</span></label>`).join('');
    const otherHtml = otherItems.map(item => {
      const value = state.moreOptions[item.id] || '';
      if (item.type === 'textarea') return `<div class="phs-ai-field"><label class="phs-ai-label" for="option-${escapeHtml(item.id)}">${escapeHtml(item.label)}</label><textarea class="phs-ai-textarea" id="option-${escapeHtml(item.id)}" data-option-id="${escapeHtml(item.id)}" placeholder="${escapeHtml(item.placeholder || '')}">${escapeHtml(value)}</textarea></div>`;
      const maxLength = item.maxLength ? ` maxlength="${Number(item.maxLength)}"` : '';
      return `<div class="phs-ai-field"><label class="phs-ai-label" for="option-${escapeHtml(item.id)}">${escapeHtml(item.label)}</label><input class="phs-ai-input" id="option-${escapeHtml(item.id)}" data-option-id="${escapeHtml(item.id)}" value="${escapeHtml(value)}" placeholder="${escapeHtml(item.placeholder || '')}"${maxLength}></div>`;
    }).join('');
    return `<section class="phs-ai-options${openClass}"><button class="phs-ai-options-head" id="toggle-more" type="button">${state.moreOptionsOpen ? '▾' : '▸'} More options</button><div class="phs-ai-options-body"><div class="phs-ai-grid">${checkboxHtml}${otherHtml}</div></div></section>`;
  }

  function render() {
    const mode = root.modeConfig[state.mode];
    const workflowsClass = `phs-ai-workflows${state.mode === 'create' ? ' create-mode' : ''}`;
    const fieldsHtml = visibleFields().map(renderField).join('');
    const reminder = state.mode === 'curriculum'
      ? 'Attach your existing unit, planning template, or curriculum source in the AI chat before sending if you have one.'
      : 'Attach or paste any source material in the AI chat before sending if you have it.';
    const previewClass = state.showPreview && state.lastPrompt ? 'phs-ai-preview show' : 'phs-ai-preview';
    const previewText = escapeHtml(state.lastPrompt || '');

    app.innerHTML = `<div class="phs-ai-shell">
      <section class="phs-ai-drawer open" aria-label="PHS AI Assistant">
        <div class="phs-ai-head">
          <div>
            <div class="phs-ai-eyebrow">Pukekohe High School</div>
            <div class="phs-ai-title">AI Assistant</div>
            <div class="phs-ai-subtitle">Working in ${escapeHtml(platform)}</div>
          </div>
          <div class="phs-ai-controls"><button class="phs-ai-icon-btn" id="collapse" type="button" title="Collapse" aria-label="Collapse PHS AI Assistant">›</button></div>
        </div>
        <div class="phs-ai-body">
          <div class="phs-ai-tabs">
            <button class="phs-ai-tab ${state.mode === 'curriculum' ? 'active' : ''}" data-mode="curriculum" type="button"><div class="phs-ai-tab-title">Curriculum</div><div class="phs-ai-tab-sub">Align and plan</div></button>
            <button class="phs-ai-tab ${state.mode === 'create' ? 'active' : ''}" data-mode="create" type="button"><div class="phs-ai-tab-title">Create Resource</div><div class="phs-ai-tab-sub">Build teaching resources</div></button>
          </div>
          <div class="phs-ai-intro">${escapeHtml(mode.intro)}</div>
          <div class="phs-ai-section-title">Choose a workflow</div>
          <div class="${workflowsClass}">${mode.workflows.map(workflow => `<button class="phs-ai-workflow ${activeWorkflowId() === workflow.id ? 'selected' : ''}" data-workflow="${escapeHtml(workflow.id)}" type="button"><div class="phs-ai-workflow-title">${escapeHtml(workflow.label)}</div><div class="phs-ai-workflow-sub">${escapeHtml(workflow.sublabel || '')}</div></button>`).join('')}</div>
          <div class="phs-ai-section-title">Add the essentials</div>
          <div class="phs-ai-grid">${fieldsHtml}</div>
          <div class="phs-ai-help" style="margin-top:8px;">${escapeHtml(reminder)}</div>
          ${renderMoreOptions()}
          <div class="phs-ai-actions"><button class="phs-ai-primary" id="insert-btn" type="button">Insert into AI</button><button class="phs-ai-secondary" id="copy-btn" type="button">Copy prompt</button></div>
          <section class="${previewClass}"><div class="phs-ai-section-title">Generated prompt preview</div><div class="phs-ai-preview-box">${previewText}</div></section>
        </div>
        <div class="phs-ai-foot">
          <div class="phs-ai-status ${escapeHtml(state.status.kind)}">${escapeHtml(state.status.text)}</div>
          <div class="phs-ai-footer-meta">PHS AI Assistant v1.13 · <button id="phs-tools-btn" type="button" style="border:0;background:none;padding:0;color:#6f2030;font:inherit;cursor:pointer;text-decoration:underline;">PHS files</button> · <button id="full-builder-btn" type="button" style="border:0;background:none;padding:0;color:#6f2030;font:inherit;cursor:pointer;text-decoration:underline;">Full Builder</button> · <button id="reset-prefs" type="button" style="border:0;background:none;padding:0;color:#6f2030;font:inherit;cursor:pointer;text-decoration:underline;">Reset prefs</button></div>
          ${state.toolsOpen ? `<div id="phs-tools-panel" style="margin-top:9px;padding-top:9px;border-top:1px solid #e6ece9;display:grid;gap:9px;">
            <div style="font-size:11px;font-weight:800;color:#3a4a45;">PHS files & attachments</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
              <button class="phs-ai-secondary" id="attach-files" type="button" style="min-height:40px;">Open AI file picker</button>
              <button class="phs-ai-secondary" id="attach-templates" type="button" style="min-height:40px;">Try attach PHS templates</button>
              <button class="phs-ai-secondary" id="attach-shield" type="button" style="min-height:40px;">Try attach PHS shield</button>
              <button class="phs-ai-secondary" id="close-tools" type="button" style="min-height:40px;">Close tools</button>
            </div>
            <div id="phs-file-note" style="font-size:10.5px;color:#62726c;line-height:1.35;">${escapeHtml(state.fileNote)}</div>
            ${renderFileShelf()}
            <div style="font-size:10.5px;color:#62726c;line-height:1.45;">GitHub source fallback:</div>
            <div style="display:flex;flex-wrap:wrap;gap:8px;font-size:10.5px;">
              <a href="${PHS_MANUAL_LINKS.shield}" target="_blank" rel="noopener noreferrer" style="color:#215f49;font-weight:800;">Shield.webp</a>
              <a href="${PHS_MANUAL_LINKS.lessonPlan}" target="_blank" rel="noopener noreferrer" style="color:#215f49;font-weight:800;">Lesson plan template</a>
              <a href="${PHS_MANUAL_LINKS.juniorUnitPlan}" target="_blank" rel="noopener noreferrer" style="color:#215f49;font-weight:800;">Junior unit plan</a>
            </div>
          </div>` : ''}
        </div>
      </section>
    </div>`;
    bindEvents();
  }

  function bindEvents() {
    const byId = id => document.getElementById(id);
    byId('collapse')?.addEventListener('click', () => post('PHS_QUICK_COLLAPSE'));
    byId('insert-btn')?.addEventListener('click', handleInsert);
    byId('copy-btn')?.addEventListener('click', handleCopy);
    byId('reset-prefs')?.addEventListener('click', handleResetPrefs);
    byId('toggle-more')?.addEventListener('click', () => { state.moreOptionsOpen = !state.moreOptionsOpen; render(); });
    byId('phs-tools-btn')?.addEventListener('click', () => { state.toolsOpen = !state.toolsOpen; if (state.toolsOpen) preloadBuiltInFiles(); render(); });
    byId('close-tools')?.addEventListener('click', () => { state.toolsOpen = false; render(); });
    byId('full-builder-btn')?.addEventListener('click', () => post('PHS_QUICK_FULL_BUILDER'));
    byId('attach-files')?.addEventListener('click', () => post('PHS_QUICK_ACTION', { action: 'attach-files' }));
    byId('attach-templates')?.addEventListener('click', () => post('PHS_QUICK_ACTION', { action: 'attach-templates' }));
    byId('attach-shield')?.addEventListener('click', () => post('PHS_QUICK_ACTION', { action: 'attach-shield' }));
    byId('add-my-files')?.addEventListener('click', () => byId('staged-file-picker')?.click());
    byId('staged-file-picker')?.addEventListener('change', event => { addStagedFiles(event.target.files); event.target.value = ''; });
    document.querySelectorAll('[data-download-builtin]').forEach(button => button.addEventListener('click', () => downloadBuiltInFile(button.getAttribute('data-download-builtin'))));
    document.querySelectorAll('[data-download-bundle]').forEach(button => button.addEventListener('click', downloadBuiltInBundle));
    document.querySelectorAll('[data-download-staged]').forEach(button => button.addEventListener('click', () => downloadStagedFile(button.getAttribute('data-download-staged'))));
    document.querySelectorAll('[data-remove-staged]').forEach(button => button.addEventListener('click', () => removeStagedFile(button.getAttribute('data-remove-staged'))));
    document.querySelectorAll('[data-drag-source]').forEach(card => card.addEventListener('dragstart', handleFileDragStart));

    document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => setMode(button.getAttribute('data-mode'))));
    document.querySelectorAll('[data-workflow]').forEach(button => button.addEventListener('click', () => setWorkflow(button.getAttribute('data-workflow'))));
    document.querySelectorAll('[data-field-id]').forEach(input => {
      const fieldId = input.getAttribute('data-field-id');
      input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', event => setField(fieldId, event.target.value));
    });
    document.querySelectorAll('[data-option-id]').forEach(input => {
      const optionId = input.getAttribute('data-option-id');
      const handler = event => setMoreOption(optionId, input.type === 'checkbox' ? event.target.checked : event.target.value);
      input.addEventListener(input.type === 'checkbox' || input.tagName === 'SELECT' ? 'change' : 'input', handler);
    });
  }

  window.addEventListener('message', event => {
    const data = event.data || {};
    if (data.type === 'PHS_HOST_INIT') {
      platform = data.platform || platform;
      if (data.fileNote) state.fileNote = data.fileNote;
      render();
      return;
    }
    if (data.type === 'PHS_HOST_STATUS') {
      if (data.fileNote) state.fileNote = data.fileNote;
      state.status = { text: String(data.text || state.status.text), kind: data.kind || '' };
      if (typeof data.showPreview === 'boolean') state.showPreview = data.showPreview;
      render();
    }
  });

  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const tag = event.target?.tagName?.toLowerCase?.() || '';
    const insideInput = tag === 'input' || tag === 'textarea' || tag === 'select' || event.target?.isContentEditable;
    if (!insideInput) post('PHS_QUICK_COLLAPSE');
  });

  (async () => {
    preloadBuiltInFiles();
    const prefs = await storageGet();
    if (prefs) {
      state.mode = prefs.mode || state.mode;
      state.selectedWorkflowByMode = { ...state.selectedWorkflowByMode, ...(prefs.selectedWorkflowByMode || {}) };
      state.fields.yearLevel = prefs.yearLevel || state.fields.yearLevel;
      state.fields.intendedTeachingYear = prefs.intendedTeachingYear || state.fields.intendedTeachingYear;
    }
    const extras = root.resourceExtraFields[state.selectedWorkflowByMode.create] || [];
    extras.forEach(field => { state.workflowSpecific[field.id] = field.defaultValue || ''; });
    render();
    post('PHS_QUICK_READY');
  })();
})();
