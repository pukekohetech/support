(() => {
  const root = window.PHSAI = window.PHSAI || {};

  const CUSTOM_SUBJECT = 'Other / custom subject';
  const CUSTOM_FOCUS = 'Other / teacher-defined focus';
  const WHOLE_AREA = 'Whole learning area / multiple strands';

  const SOURCES = {
    english: {
      learningArea: 'English',
      title: 'The New Zealand Curriculum – English Years 0–10',
      date: '2025; in effect from 1 January 2026',
      status: 'OFFICIAL current Years 0–10 curriculum statement for English.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637289328.p'
    },
    mathematics: {
      learningArea: 'Mathematics and Statistics',
      title: 'Curriculum Statement – The New Zealand Curriculum: Mathematics and Statistics Years 0–10 (2025)',
      date: '2025; in effect from 1 January 2026',
      status: 'OFFICIAL current Years 0–10 curriculum statement for Mathematics and Statistics.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637289330.p'
    },
    science: {
      learningArea: 'Science',
      title: 'The New Zealand Curriculum – Science Years 0–10 2026',
      date: 'Released 12 August 2026',
      status: 'UPDATED 2026 content for 2027 planning. Tāhūrangi states it is proposed to become a National Curriculum Statement; verify current Gazette/status before consequential use.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637290855.p'
    },
    socialSciences: {
      learningArea: 'Social Sciences',
      title: 'The New Zealand Curriculum – Social Sciences Years 0–10 2026',
      date: 'Released 12 August 2026',
      status: 'UPDATED 2026 content for 2027 planning. Tāhūrangi states it is proposed to become a National Curriculum Statement; verify current Gazette/status before consequential use.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637290851.p'
    },
    technology: {
      learningArea: 'Technology',
      title: 'The New Zealand Curriculum – Technology Years 0–10',
      date: 'September 2026',
      status: 'UPDATED September 2026 content for 2027 Years 9–10 planning. The supplied September 2026 PDF states it is proposed to become a National Curriculum Statement and will be replaced by the Gazette-made official version once published.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637293836.p'
    },
    learningLanguages: {
      learningArea: 'Learning Languages',
      title: 'The New Zealand Curriculum – Learning Languages Years 0–10',
      date: 'Released 9 September 2026',
      status: 'UPDATED September 2026 content. Tāhūrangi states it is proposed to become a National Curriculum Statement; Years 9–10 are expected to start using it from 1 January 2027. Verify the current language-specific teaching sequence and Gazette/status.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637293835.p'
    },
    hpe: {
      learningArea: 'Health and Physical Education',
      title: 'Health and Physical Education Years 0–10 – latest available updated structure',
      date: 'Status checked 9 September 2026',
      status: 'PENDING FINAL UPDATED RELEASE. Tāhūrangi stated on 9 September 2026 that Health and Physical Education Years 0–10 was still in the final stages of completion. The focus choices use the latest published draft structure only and MUST be re-verified before use.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637293829.p'
    },
    arts: {
      learningArea: 'The Arts',
      title: 'The Arts Years 0–10 – latest available updated structure',
      date: 'Status checked 9 September 2026',
      status: 'PENDING FINAL UPDATED RELEASE. Tāhūrangi stated on 9 September 2026 that The Arts Years 0–10 was still in the final stages of completion. The focus choices use the latest published draft structure only and MUST be re-verified before use.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/5637290850.p'
    },
    senior: {
      learningArea: 'Senior secondary / subject-specific',
      title: 'Current senior curriculum and NZQA subject sources — live verification required',
      date: 'Transition period 2026–2030',
      status: 'SENIOR / TRANSITIONAL. Do not use Years 0–10 strand mappings as senior requirements. Verify the current subject-specific Years 11–13 curriculum, the intended teaching year, and NZQA standard/version where assessment is involved. Updated senior curriculum is being implemented progressively from Year 11 in 2028, Year 12 in 2029, and Year 13 in 2030.',
      url: 'https://newzealandcurriculum.tahurangi.education.govt.nz/'
    },
    custom: {
      learningArea: 'Teacher-defined / local course',
      title: 'No single national curriculum source is assumed',
      date: 'Teacher-defined',
      status: 'CUSTOM mapping. Verify the applicable national curriculum learning area, local course intent, and any official requirements before making alignment judgements.',
      url: ''
    }
  };

  const SUBJECTS = [
    // Core / learning areas
    { value: 'English', source: 'english', kind: 'english' },
    { value: 'ESOL / English as an Additional Language', source: 'learningLanguages', kind: 'language' },
    { value: 'Mathematics & Statistics', source: 'mathematics', kind: 'mathematics' },
    { value: 'Science', source: 'science', kind: 'science' },
    { value: 'Biology', source: 'science', kind: 'scienceBiological' },
    { value: 'Chemistry', source: 'science', kind: 'sciencePhysical' },
    { value: 'Physics', source: 'science', kind: 'sciencePhysical' },
    { value: 'Social Sciences / Social Studies', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'History', source: 'socialSciences', kind: 'history' },
    { value: 'Geography', source: 'socialSciences', kind: 'geography' },
    { value: 'Economics / Business', source: 'socialSciences', kind: 'economics' },
    { value: 'Money Matters', source: 'socialSciences', kind: 'economics' },
    { value: 'Health & Physical Education / PE', source: 'hpe', kind: 'hpe' },
    { value: 'Health Education', source: 'hpe', kind: 'health' },
    { value: 'Physical Education', source: 'hpe', kind: 'physicalEducation' },

    // Technology subjects used at PHS
    { value: 'Design & Visual Communication / Design Thinking', source: 'technology', kind: 'technologySpatial' },
    { value: 'Digital Technology', source: 'technology', kind: 'technologyDigital' },
    { value: 'Food Technology', source: 'technology', kind: 'technologyFood' },
    { value: 'Multi-materials / Hard Technology', source: 'technology', kind: 'technologyMaterials' },
    { value: 'Electronics', source: 'technology', kind: 'technologySystems' },
    { value: 'STEM', source: 'technology', kind: 'technologyGeneral', mappingNote: 'PHS STEM may integrate more than one learning area. Do not assume Technology is the only applicable learning area; verify the actual course/unit scope.' },
    { value: 'Production Studies', source: 'science', kind: 'science', mappingNote: 'PHS course title shown within the Science faculty. Verify the exact local course intent before deciding which Science content applies.' },
    { value: 'Technology – General / Integrated', source: 'technology', kind: 'technologyGeneral' },

    // Arts subjects used at PHS
    { value: 'Art', source: 'arts', kind: 'visualArts' },
    { value: 'Creative Enterprise', source: 'arts', kind: 'artsGeneral', mappingNote: 'PHS local Arts course title. Verify the specific discipline(s) and unit scope before consequential alignment.' },
    { value: 'Cinematography / Motion Graphics & Animation', source: 'arts', kind: 'visualArts', mappingNote: 'PHS local Arts course title; mapped provisionally to Visual Arts for junior curriculum selection and must be verified against the unit intent.' },
    { value: 'Music Core', source: 'arts', kind: 'music' },
    { value: 'Music Band', source: 'arts', kind: 'music' },
    { value: 'Music', source: 'arts', kind: 'music' },
    { value: 'Visual Arts', source: 'arts', kind: 'visualArts' },
    { value: 'Photo Design', source: 'arts', kind: 'visualArts', mappingNote: 'Photo Design is mapped provisionally to Visual Arts; verify the local course intent before consequential alignment.' },
    { value: 'Dance', source: 'arts', kind: 'dance' },
    { value: 'Drama', source: 'arts', kind: 'drama' },
    { value: 'Dance / Drama Combined', source: 'arts', kind: 'danceDrama' },
    { value: 'Te Ao Haka', source: 'arts', kind: 'artsGeneral', mappingNote: 'PHS counts Te Ao Haka as an Arts selection, but do not assume a single national Arts strand; verify the local course scope.' },
    { value: 'Ngā Toi', source: 'arts', kind: 'artsGeneral', mappingNote: 'PHS counts Ngā Toi as an Arts selection, but do not assume a single national Arts strand; verify the local course scope.' },
    { value: 'The Arts – General / Integrated', source: 'arts', kind: 'artsGeneral' },

    // Additional PHS senior subjects / course titles (2026 curriculum map; senior use is always live-verified)
    { value: 'Contemporary Literature', source: 'english', kind: 'english' },
    { value: 'World Literature', source: 'english', kind: 'english' },
    { value: 'English Scholarship', source: 'english', kind: 'english', mappingNote: 'PHS senior course title. Verify the current scholarship/senior curriculum expectations rather than inferring them from Years 0–10.' },
    { value: 'Mathematics Core', source: 'mathematics', kind: 'mathematics' },
    { value: 'Mathematics with Algebra', source: 'mathematics', kind: 'mathematics' },
    { value: 'Mathematics with Statistics', source: 'mathematics', kind: 'mathematics' },
    { value: 'General Mathematics', source: 'mathematics', kind: 'mathematics' },
    { value: 'Calculus', source: 'mathematics', kind: 'mathematics' },
    { value: 'Statistics', source: 'mathematics', kind: 'mathematics' },
    { value: 'Science General', source: 'science', kind: 'science' },
    { value: 'General Science', source: 'science', kind: 'science' },
    { value: 'Agriculture & Horticulture', source: 'science', kind: 'science', mappingNote: 'PHS senior Science course title; verify the current subject curriculum and standards.' },
    { value: 'Science in Context', source: 'science', kind: 'science' },
    { value: 'Earth Science', source: 'science', kind: 'science' },
    { value: 'Agriculture & Horticulture Science', source: 'science', kind: 'science', mappingNote: 'PHS course title within the Science faculty; verify the exact current senior subject curriculum and standards.' },
    { value: 'Agriculture & Horticultural Science', source: 'science', kind: 'science', mappingNote: 'PHS senior course title; verify the exact current senior subject curriculum and standards.' },
    { value: 'Agriculture Science', source: 'science', kind: 'science', mappingNote: 'PHS senior course title; verify the current subject curriculum and standards.' },
    { value: 'Horticultural Science', source: 'science', kind: 'science', mappingNote: 'PHS senior course title; verify the current subject curriculum and standards.' },
    { value: 'People & Society', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Psychology', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Classical Studies', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Tourism', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Media Studies', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Commerce', source: 'socialSciences', kind: 'economics' },
    { value: 'Accounting', source: 'socialSciences', kind: 'economics' },
    { value: 'Business Studies', source: 'socialSciences', kind: 'economics' },
    { value: 'Economics', source: 'socialSciences', kind: 'economics' },
    { value: 'Legal Studies', source: 'socialSciences', kind: 'socialSciences' },
    { value: 'Health', source: 'hpe', kind: 'health' },
    { value: 'Outdoor Education', source: 'hpe', kind: 'physicalEducation' },
    { value: 'Sports Leadership', source: 'hpe', kind: 'physicalEducation' },
    { value: 'Spatial Design', source: 'technology', kind: 'technologySpatial' },
    { value: 'Computer Applications', source: 'technology', kind: 'technologyDigital' },
    { value: 'Computer Application', source: 'technology', kind: 'technologyDigital' },
    { value: 'Digital Technologies / PTECH', source: 'technology', kind: 'technologyDigital' },
    { value: 'Digital Technology (P-Tech)', source: 'technology', kind: 'technologyDigital' },
    { value: 'Computer Science', source: 'technology', kind: 'technologyDigital', mappingNote: 'PHS senior Technology course title. Verify the current senior curriculum and assessment standards.' },
    { value: 'Digital Design', source: 'technology', kind: 'technologyDigital' },
    { value: 'Food & Nutrition', source: 'technology', kind: 'technologyFood' },
    { value: 'Catering', source: 'technology', kind: 'technologyFood' },
    { value: 'Engineering', source: 'technology', kind: 'technologyMaterials', mappingNote: 'PHS Engineering may draw on Materials Technology and/or Systems and Control. For senior use, verify the exact current course curriculum and standards.' },
    { value: 'Building', source: 'technology', kind: 'technologyMaterials', mappingNote: 'PHS Building is a senior course title. Verify the exact current course curriculum, unit standards, and intended scope rather than inferring a Years 0–10 strand.' },
    { value: 'Hard Materials Technology', source: 'technology', kind: 'technologyMaterials' },
    { value: 'Art – Painting & Printmaking', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Design', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Motion Special Effects', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Photography & Design', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Painting', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Photography', source: 'arts', kind: 'visualArts' },
    { value: 'Art – Printmaking', source: 'arts', kind: 'visualArts' },
    { value: 'Art – History', source: 'arts', kind: 'visualArts' },
    { value: 'Performance Music', source: 'arts', kind: 'music' },
    { value: 'Core Foundation', source: 'custom', kind: 'customCourse', mappingNote: 'PHS Learning Support course. Use teacher/local programme requirements; do not invent a national curriculum strand.' },
    { value: 'Core Foundations', source: 'custom', kind: 'customCourse', mappingNote: 'PHS Learning Support course. Use teacher/local programme requirements; do not invent a national curriculum strand.' },
    { value: 'Foundation Certificate', source: 'custom', kind: 'customCourse', mappingNote: 'PHS Learning Support course. Use teacher/local programme requirements; do not invent a national curriculum strand.' },
    { value: 'Life Skills', source: 'custom', kind: 'customCourse', mappingNote: 'PHS Learning Support course. Use teacher/local programme requirements; do not invent a national curriculum strand.' },
    { value: 'Future Pathways', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Hospitality Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Engineering Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Building Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Primary Industries Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Electrical Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Automotive Pathway', source: 'custom', kind: 'customCourse', mappingNote: 'PHS pathway course. Verify the specific programme, qualification, or standards being used.' },
    { value: 'Te Manaaki Taangata Ki Te Māori', source: 'custom', kind: 'customCourse', mappingNote: 'PHS local course title. Use the teacher/local programme requirements and verify any national curriculum or qualification links before alignment.' },

    // Languages / Te Wāhanga
    { value: 'French', source: 'learningLanguages', kind: 'language' },
    { value: 'Japanese', source: 'learningLanguages', kind: 'language' },
    { value: 'Te Reo Māori', source: 'learningLanguages', kind: 'language' },
    { value: 'Te Ao Māori', source: 'custom', kind: 'customCourse', mappingNote: 'Local course title: verify whether the intended learning is best aligned to Learning Languages, Social Sciences, The Arts, or a locally defined scope.' },
    { value: 'Mātauranga Māori', source: 'custom', kind: 'customCourse', mappingNote: 'Local course title: verify the intended learning area and local programme scope rather than assigning an official strand from the title alone.' },
    { value: 'Learning Languages – Other', source: 'learningLanguages', kind: 'language' },

    { value: CUSTOM_SUBJECT, source: 'custom', kind: 'customSubject' }
  ];

  function yearNumber(yearLevel) {
    const match = String(yearLevel || '').match(/Year\s+(\d+)/i);
    return match ? Number(match[1]) : null;
  }

  function withCommon(options) {
    const clean = Array.from(new Set(options.filter(Boolean)));
    return ['', WHOLE_AREA, ...clean, CUSTOM_FOCUS];
  }

  function technologyStrands(yearLevel) {
    const year = yearNumber(yearLevel);
    const common = [
      'Design, Make, and Innovate',
      'Materials Technology (Resistant and Textiles)',
      'Food and Processing Technology',
      'Systems and Control',
      'Digital Technology'
    ];
    if (!year || year >= 9) common.splice(1, 0, 'Spatial and Product Design');
    return common;
  }

  function artsStrands(yearLevel) {
    const year = yearNumber(yearLevel);
    if (year && year <= 8) return ['Performing Arts', 'Music', 'Visual Arts'];
    return ['Dance', 'Drama', 'Music', 'Visual Arts'];
  }

  function englishStrands(yearLevel) {
    const year = yearNumber(yearLevel);
    if (year && year <= 8) return ['Oral Language', 'Reading', 'Writing'];
    return ['Text Studies', 'Language Studies'];
  }

  function subjectEntry(subject) {
    return SUBJECTS.find(item => item.value === subject) || SUBJECTS.find(item => item.value === CUSTOM_SUBJECT);
  }

  function subjectSpecificFocuses(entry, yearLevel) {
    const senior = (yearNumber(yearLevel) || 0) >= 11;
    if (senior) return ['Whole current senior subject / learning area', 'NCEA / assessment-standard focus'];

    switch (entry.kind) {
      case 'english': return englishStrands(yearLevel);
      case 'mathematics': return ['Number', 'Algebra', 'Measurement', 'Geometry', 'Statistics', 'Probability'];
      case 'science': return ['Physical Science', 'Biological Science'];
      case 'scienceBiological': return ['Biological Science', 'Physical Science'];
      case 'sciencePhysical': return ['Physical Science', 'Biological Science'];
      case 'socialSciences': return ['History', 'Civics and Society', 'Geography', 'Financial and Economic Activity'];
      case 'history': return ['History'];
      case 'geography': return ['Geography'];
      case 'economics': return ['Financial and Economic Activity'];
      case 'hpe': return ['Health Education', 'Physical Education'];
      case 'health': return ['Health Education'];
      case 'physicalEducation': return ['Physical Education'];
      case 'technologySpatial': {
        const strands = technologyStrands(yearLevel);
        return strands.includes('Spatial and Product Design') ? ['Spatial and Product Design', 'Design, Make, and Innovate'] : ['Design, Make, and Innovate'];
      }
      case 'technologyDigital': return ['Digital Technology', 'Design, Make, and Innovate'];
      case 'technologyFood': return ['Food and Processing Technology', 'Design, Make, and Innovate'];
      case 'technologyMaterials': return ['Materials Technology (Resistant and Textiles)', 'Design, Make, and Innovate'];
      case 'technologySystems': return ['Systems and Control', 'Design, Make, and Innovate'];
      case 'technologyGeneral': return technologyStrands(yearLevel);
      case 'music': return ['Music'];
      case 'visualArts': return ['Visual Arts'];
      case 'dance': return ['Dance'];
      case 'drama': return ['Drama'];
      case 'danceDrama': return ['Dance', 'Drama'];
      case 'artsGeneral': return artsStrands(yearLevel);
      case 'language': return [
        'Whole language-specific teaching sequence',
        'Communication / purposeful language use',
        'Linguistic knowledge',
        'Cultural and sociolinguistic knowledge'
      ];
      case 'customCourse':
      case 'customSubject':
      default: return [];
    }
  }

  function curriculumStructure(entry, yearLevel, focusLabel, customFocus) {
    const year = yearNumber(yearLevel);
    const requiredCompanions = [];
    const programmeRequirements = [];
    const conditionalRequirements = [];
    const primaryFocus = String(focusLabel || '').trim();
    const hasMappedFocus = primaryFocus && primaryFocus !== WHOLE_AREA && primaryFocus !== CUSTOM_FOCUS;

    if (year && year >= 11) {
      conditionalRequirements.push('Years 11–13 curriculum structures are in transition. Verify the current subject-specific senior curriculum and, where assessment is involved, the applicable NZQA standard/version before applying companion, programme-level, or progression requirements.');
      return { primaryFocus, requiredCompanions, programmeRequirements, conditionalRequirements };
    }

    if (entry.source === 'technology') {
      const disciplineStrands = [
        'Spatial and Product Design',
        'Materials Technology (Resistant and Textiles)',
        'Food and Processing Technology',
        'Systems and Control',
        'Digital Technology'
      ];
      if (disciplineStrands.includes(primaryFocus)) {
        requiredCompanions.push('Design, Make, and Innovate — the underpinning Technology strand whose common knowledge and practice must be applied through the selected discipline-specific strand.');
      } else if (primaryFocus === 'Design, Make, and Innovate') {
        conditionalRequirements.push('Design, Make, and Innovate is an underpinning strand. Confirm which discipline-specific Technology strand(s) provide the authentic context for its enactment rather than treating it as an isolated discipline.');
      } else if (primaryFocus && primaryFocus !== WHOLE_AREA) {
        conditionalRequirements.push('This Technology focus is teacher-defined or non-standard. Verify which current discipline-specific Technology strand it belongs to; once verified, apply Design, Make, and Innovate as the underpinning strand where required.');
      }
      if (year === 9 || year === 10) {
        programmeRequirements.push('Across each of Years 9 and 10, each student must be taught Design, Make, and Innovate through at least two discipline-specific Technology strands. Treat this as a whole-programme requirement unless the teacher is auditing the complete Year 9 or Year 10 programme.');
      }
    }

    if (entry.source === 'mathematics' && (!year || year <= 10)) {
      requiredCompanions.push('Mathematical and statistical processes — investigating, representing and connecting situations, and generalising, explaining, and justifying findings — are fundamental to all Mathematics and Statistics teaching and must be considered alongside the selected content strand.');
    }

    if (entry.source === 'science' && (!year || year <= 10)) {
      requiredCompanions.push('Science practices — investigation, evaluation, communication, and application — are developed alongside scientific knowledge and must be considered with the selected Science strand.');
    }

    if (entry.source === 'socialSciences' && (!year || year <= 10) && hasMappedFocus) {
      requiredCompanions.push('Use both the knowledge and practices associated with the selected Social Sciences strand; do not infer that the other Social Sciences strands are unit-level requirements.');
    }

    if (entry.source === 'english' && (year === 9 || year === 10)) {
      programmeRequirements.push('Years 9–10 English advances subject-English through integrated study of Text Studies and Language Studies. Check relevant connections across the programme, but do not force equal coverage of both strands into every individual unit.');
    }

    if (entry.source === 'learningLanguages' && (!year || year <= 10)) {
      programmeRequirements.push('Learning Languages is structured around Linguistic knowledge and Cultural and sociolinguistic knowledge, with students learning through communication modes appropriate to the language. Check both strands and relevant communication modes across the programme without forcing every mode into every unit.');
      conditionalRequirements.push('Do not infer proficiency sequence from year level alone. Confirm the applicable language-specific sequence — Novice 1, Novice 2, Emergent 1, or Emergent 2 — when it is not already clear from the teacher context or verified source.');
    }

    if (entry.source === 'hpe' && (!year || year <= 10)) {
      conditionalRequirements.push('The fully updated Years 0–10 Health and Physical Education release was still pending on the latest checked Ministry update. Re-verify the current release and its organising structure before applying any strand, companion, or programme-level rule.');
    }

    if (entry.source === 'arts' && (!year || year <= 10)) {
      conditionalRequirements.push('The fully updated Years 0–10 The Arts release was still pending on the latest checked Ministry update. Re-verify the current release and its organising structure before applying any strand, companion, or programme-level rule.');
    }

    if (entry.source === 'custom') {
      conditionalRequirements.push('This is a local or teacher-defined course mapping. Verify the applicable national learning area, local course intent, and any compulsory companion or programme-level requirements before making alignment judgements.');
    }

    if (customFocus) {
      conditionalRequirements.push('The selected curriculum focus is teacher-defined. Verify how it maps to the current official curriculum structure; do not present it as an official strand unless authoritative evidence confirms that status.');
    }

    return { primaryFocus, requiredCompanions, programmeRequirements, conditionalRequirements };
  }

  root.curriculumCatalogVerifiedOn = '2026-09-11';
  root.curriculumCustomSubjectValue = CUSTOM_SUBJECT;
  root.curriculumCustomFocusValue = CUSTOM_FOCUS;
  root.curriculumWholeAreaValue = WHOLE_AREA;
  root.curriculumSources = SOURCES;
  root.curriculumSubjects = SUBJECTS;

  root.curriculumFieldChangeNeedsRender = function(fieldId) {
    return ['subject', 'curriculumFocus', 'yearLevel', 'intendedTeachingYear'].includes(String(fieldId || ''));
  };

  root.curriculumSubjectOptions = function() {
    return [{ value: '', label: 'Choose subject / learning area…' }, ...SUBJECTS.map(item => ({ value: item.value, label: item.value }))];
  };

  root.curriculumFocusOptions = function(subject, yearLevel, intendedTeachingYear) {
    void intendedTeachingYear;
    if (!String(subject || '').trim()) {
      return [{ value: '', label: 'Choose subject first…' }];
    }
    const entry = subjectEntry(subject);
    const focuses = withCommon(subjectSpecificFocuses(entry, yearLevel));
    return focuses.map(value => ({
      value,
      label: value === '' ? 'Choose curriculum focus / strand…' : value
    }));
  };

  root.curriculumSourceHelp = function(subject, yearLevel, intendedTeachingYear) {
    if (!subject) return 'Choose the subject first. Focus choices come from the latest mapped Years 0–10 curriculum structure and are re-verified by the AI before it proceeds.';
    const entry = subjectEntry(subject);
    const mappedSource = SOURCES[entry.source] || SOURCES.custom;
    const year = yearNumber(yearLevel);
    const source = year && year >= 11 ? { ...SOURCES.senior, learningArea: mappedSource.learningArea } : mappedSource;
    const seniorNote = year && year >= 11 ? ' Senior curriculum is not inferred from the Years 0–10 mapping; the AI must verify the current senior statement/NCEA context.' : '';
    const futureNote = intendedTeachingYear && intendedTeachingYear !== 'Current year' ? ` Intended teaching year: ${intendedTeachingYear}.` : '';
    return `${source.status}${seniorNote}${futureNote}`;
  };

  root.resolveCurriculumSelection = function(fields) {
    const info = fields || {};
    const entry = subjectEntry(info.subject);
    const mappedSource = SOURCES[entry.source] || SOURCES.custom;
    const senior = (yearNumber(info.yearLevel) || 0) >= 11;
    const source = senior ? { ...SOURCES.senior, learningArea: mappedSource.learningArea } : mappedSource;
    const customSubject = info.subject === CUSTOM_SUBJECT;
    const customFocus = info.curriculumFocus === CUSTOM_FOCUS;
    const subjectLabel = customSubject ? String(info.customSubject || '').trim() : String(info.subject || '').trim();
    const focusLabel = customFocus ? String(info.customCurriculumFocus || '').trim() : String(info.curriculumFocus || '').trim();
    const techDiscipline = entry.source === 'technology' && focusLabel && focusLabel !== 'Design, Make, and Innovate' && focusLabel !== WHOLE_AREA && focusLabel !== CUSTOM_FOCUS;
    const focusKind = customFocus
      ? 'teacher-defined curriculum focus; not automatically an official curriculum strand'
      : entry.source === 'learningLanguages'
        ? 'curriculum focus drawn from the language-specific Years 0–10 structure; verify the exact current teaching sequence for the selected language'
        : focusLabel === WHOLE_AREA
          ? 'whole learning area / multiple strands'
          : 'mapped curriculum strand/focus; must be verified against the current authoritative source';

    const structure = curriculumStructure(entry, info.yearLevel, focusLabel, customFocus);

    return {
      subjectLabel,
      selectedSubjectValue: String(info.subject || '').trim(),
      learningArea: customSubject ? 'Teacher-defined / to verify' : source.learningArea,
      focusLabel,
      focusKind,
      isCustomSubject: customSubject,
      isCustomFocus: customFocus,
      sourceTitle: source.title,
      sourceDate: source.date,
      sourceStatus: source.status,
      sourceUrl: source.url,
      mappingVerifiedOn: root.curriculumCatalogVerifiedOn,
      mappingNote: entry.mappingNote || '',
      underpinningStrand: techDiscipline ? 'Design, Make, and Innovate' : '',
      primaryFocus: structure.primaryFocus,
      requiredCompanions: structure.requiredCompanions,
      programmeRequirements: structure.programmeRequirements,
      conditionalRequirements: structure.conditionalRequirements,
      isSenior: senior
    };
  };
})();
