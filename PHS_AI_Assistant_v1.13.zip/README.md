# PHS AI Assistant v1.13

This build keeps the **original PHS AI Assistant 1.0.0 staff-friendly Curriculum / Create Resource layout**, the iframe-based Claude/Copilot typing isolation introduced in v1.6, and the PHS file/shield tools, while upgrading the Curriculum workflow with source-aware subject and curriculum-focus dropdowns.

## Main staff experience

The quick builder keeps the familiar two-tab layout:

### Curriculum
- Check alignment
- Improve & align
- Complete full document
- Create new unit
- What changed?

### Create Resource
- PowerPoint
- Worksheet
- Infographic
- Relief pack
- Assessment / Teams
- Interactive resource
- Custom

The original v1.0 stylesheet remains unchanged.

## Curriculum subject and focus dropdowns

Curriculum mode now uses a **Subject / learning area** dropdown covering the main New Zealand learning areas plus PHS junior and senior subject/course names known from current public PHS curriculum information. **Other / custom subject** is always available.

The **Curriculum focus / strand to align** dropdown changes according to the selected subject and year level. Every focus list includes:
- **Whole learning area / multiple strands**
- **Other / teacher-defined focus**

Selecting a custom subject or focus reveals a text field. Teacher-defined wording is treated as the teacher's requested scope, not automatically as an official curriculum label.

**Unit / topic is optional in Curriculum mode.**

## Curriculum source catalog checked 11 September 2026

The built-in mappings are a convenient starting reference, not a substitute for live verification.

- **English Years 0–10:** current official curriculum, in effect from 1 January 2026. Years 9–10: Text Studies; Language Studies.
- **Mathematics and Statistics Years 0–10:** current official curriculum, in effect from 1 January 2026. Strands: Number; Algebra; Measurement; Geometry; Statistics; Probability.
- **Science Years 0–10:** updated 2026 content for 2027 planning. Mapped strands: Physical Science; Biological Science. Current status must be re-verified because Tāhūrangi describes the 2026 statement as proposed until made/published as a National Curriculum Statement.
- **Social Sciences Years 0–10:** updated 2026 content for 2027 planning. Mapped strands: History; Civics and Society; Geography; Financial and Economic Activity. Current status must be re-verified.
- **Technology Years 0–10:** based on the September 2026 curriculum supplied for this project and the current Tāhūrangi page. Years 7–10 use Design, Make, and Innovate plus discipline-specific strands; Spatial and Product Design applies in Years 9–10. The September 2026 document says it is proposed to become a National Curriculum Statement and will be replaced by the official Gazette-made version once published, so the current status must be re-verified.
- **Learning Languages Years 0–10:** updated September 2026 language-specific curriculum. The dropdown uses safe curriculum-focus categories and requires the AI to verify the exact current language-specific teaching sequence rather than pretending the categories are universal official strand labels.
- **Health and Physical Education:** the built-in focus choices use the latest available draft structure (Health Education; Physical Education). Tāhūrangi still reported the fully updated release as pending on 9 September 2026, so the prompt must re-verify before use.
- **The Arts:** the built-in choices use the latest available draft structure. Years 9–10: Dance; Drama; Music; Visual Arts. Tāhūrangi still reported the fully updated release as pending on 9 September 2026, so the prompt must re-verify before use.
- **Years 11–13:** Years 0–10 mappings are not treated as senior requirements. The dropdown provides a current senior subject/learning-area focus and an NCEA/assessment-standard focus, then requires live verification of the applicable senior curriculum and NZQA material.

## Mandatory Curriculum Verification Gate

Every Curriculum prompt now contains a **CURRICULUM VERIFICATION GATE — MUST RUN BEFORE PROCEEDING** before the ordinary execution instructions.

The AI is told to:
1. identify the selected year level, intended teaching year, subject, and focus;
2. check the most current authoritative Ministry of Education / Tāhūrangi source;
3. check New Zealand Gazette status where the mapped/supplied source is proposed, transitional, or expected to be replaced;
4. check current senior curriculum and NZQA material where Years 11–13/NCEA are involved;
5. compare current authoritative evidence with the extension's stored mapping and any teacher-supplied curriculum source;
6. continue without interruption when the evidence materially agrees;
7. **STOP before completing the task and ask the teacher** if a newer release, material mismatch, changed strand/focus structure, changed implementation requirement, unresolved source status, or another important development could affect the result;
8. never silently substitute curriculum versions or invent official wording.

This verification gate explicitly overrides the normal "complete the task now" instruction when a material curriculum issue needs teacher resolution.

## Curriculum Structure Check

After live curriculum verification, every Curriculum prompt separates **Primary focus**, **Required companions**, **Programme-level requirements**, and **Conditional requirements**. For Technology discipline-specific strands this automatically includes **Design, Make, and Innovate**; Mathematics carries its mathematical/statistical processes; Science carries investigation, evaluation, communication, and application practices; English and Learning Languages receive programme/sequence safeguards; and pending HPE/Arts structures are re-verified before use.

## Claude / Copilot typing isolation

The quick builder runs inside an extension-owned iframe rather than placing its text fields directly into the AI website DOM. This isolates keyboard events from Claude and Copilot page-level key handlers. The host composer is also guarded while the drawer is open and restored before insertion or on close.

## Launcher and PHS files

The launcher is the official Pukekohe High School shield (`Shield.webp`). The extension includes:
- `Shield.webp`
- `lesson_plan_template_PHS.docx`
- `Junior_Curriculum_Unit_Plan_Cover_Sheet.docx`

Use **PHS files** in the footer to attach your own files, the official planning templates, or the shield. If automatic attachment is blocked, direct GitHub fallback links remain available.

## Full Builder

**Full Builder** remains an advanced route and does not replace or reshape the normal quick staff interface. In v1.13 it is packaged completely inside the extension and opens in the **same side drawer**. Use **← Quick Builder** to return without closing the drawer.

The Full Builder no longer loads its executable UI from GitHub Pages. Its HTML and JavaScript are local Manifest V3 extension files. **Insert into AI**, **Copy prompt**, and PHS template/shield attachment requests use the same extension bridge and chatbot-site integration already used by the Quick Builder.

Optional live lookups such as NZQA previews may still be limited by browser cross-origin rules. If a lookup cannot run, the builder keeps the manual/open-source fallback and the generated prompt still requires the AI to verify current official information. No extra broad browser permission is added just to make an optional lookup work.

## Reliability

The quick prompt engine retains the always-on truth/evidence, smart-source, educational-quality, and final-QA rules. Nothing is sent automatically.

## Installation

1. Remove or disable the older PHS AI Assistant build.
2. Unzip this package.
3. Open `edge://extensions` or `chrome://extensions`.
4. Enable Developer mode.
5. Choose **Load unpacked** and select the extension folder.
6. Refresh ChatGPT, Claude, or Copilot.


## PHS working-files shelf

Open **PHS files** in the footer to use the file shelf. The official Shield.webp and both PHS planning DOCX templates can be downloaded individually, dragged where supported, or downloaded together as PHS_Working_Files.zip. **Add my files** stages teacher-selected local files in memory for the current assistant session only; staged files can be dragged, downloaded again, or removed. Automatic AI-site attachment remains available, but Download is the reliable fallback when Copilot, Claude, or ChatGPT blocks programmatic or cross-origin drag/drop.

## Short chat titles

Generated prompts now begin with a concise chat-title line capped at 40 characters, followed by a short task line. The title is built from year level, a compact subject label, topic/focus where available, and workflow/resource type. Staff can optionally override it in More options; overrides are also capped at 40 characters.


## Curriculum structure safeguard
Curriculum prompts now distinguish primary focus, required companions, programme-level requirements, and conditional requirements after live curriculum verification. Technology discipline strands include Design, Make, and Innovate; Mathematics and Science carry their cross-strand processes/practices; English and Learning Languages receive programme/sequence safeguards; pending HPE and Arts structures must be re-verified before use.

## Working-file reliability

The official PHS shield, lesson-plan template, junior unit-plan template, and working-files ZIP are also embedded in `phs-file-data.js`. The quick file shelf and automatic attachment actions build real `File` objects directly from those embedded bytes instead of depending on runtime `fetch()` calls. Built-in file cards report **Ready** or **Unavailable**, and downloads use Blob/object URLs generated from the embedded data.
