(() => {
  const root = window.PHSAI = window.PHSAI || {};

  root.curriculumPrompts = {
    checkAlignment: {
      quickPrompt: 'Curriculum / unit plan',
      action: 'Review / align existing work',
      title: 'Check alignment',
      purpose: `Review the supplied existing unit, lesson sequence, assessment, or planning material against the relevant New Zealand curriculum for the intended teaching year.`,
      task: `## TASK MODE: REVIEW
Review the supplied work only. Do not rewrite the whole document in the first pass.

Return concise evidence-based feedback under these headings:
- KEEP
- CHANGE
- ADD
- VERIFY

Also include the 3–5 highest-priority next actions.

Preserve useful teacher decisions. Avoid change for change's sake.`,
      fieldsNote: `If a file or draft is attached, use it as the primary basis for the review.`
    },
    improveAlign: {
      quickPrompt: 'Curriculum / unit plan',
      action: 'Improve and align',
      title: 'Improve & align',
      purpose: `Review the supplied curriculum-related work, improve it, and align it more strongly to the relevant New Zealand curriculum for the intended teaching year.`,
      task: `## TASK MODE: IMPROVE
Review the supplied work, keep what is strong, and improve only what needs improving.

Return:
1. a short summary of the most important changes made;
2. the improved content in a teacher-ready form;
3. any points that still require teacher input or local school information.

Do not stop at recommendations alone. Complete the improvements now.`,
      fieldsNote: `If a unit, lesson sequence, or partially completed document is attached, preserve its useful content and structure where possible.`
    },
    completeDocument: {
      quickPrompt: 'Curriculum / unit plan',
      action: 'Complete full document',
      title: 'Complete full document',
      purpose: `Use the supplied planning template, unit plan, or partially completed curriculum document and complete it fully using the teacher's material plus verified curriculum information where needed.`,
      task: `## TASK MODE: COMPLETE DOCUMENT
Treat any attached template or planning document as the structural authority.

- Preserve the document's headings, order, tables, and intended structure.
- Fill every section that can reasonably be completed.
- Use supplied teacher material first, then verified curriculum information to fill genuine gaps.
- Keep TEACHER INPUT NEEDED to the absolute minimum and label it clearly.

Do not return only review notes, suggestions, or an outline. Complete the document now in the same structure.`,
      fieldsNote: `This workflow works best when the teacher attaches the actual planning template or part-completed file.`
    },
    createNewUnit: {
      quickPrompt: 'Curriculum / unit plan',
      action: 'Create new',
      title: 'Create new unit',
      purpose: `Create a new curriculum-aligned unit from scratch for the stated year level, subject/learning area, and topic.`,
      task: `## TASK MODE: CREATE NEW
Select a defensible curriculum focus, identify the essential learning, and build a practical teacher-ready unit.

Include:
- a brief curriculum rationale;
- clear learning focus;
- coherent sequence/progression;
- suitable evidence of learning;
- any useful learning intentions or success indicators where they genuinely help.

If a planning template is attached, complete it using its structure. If not, produce a compact teacher-ready unit plan rather than a long essay.`,
      fieldsNote: `If the teacher attaches a preferred template or example, use it.`
    },
    whatChanged: {
      quickPrompt: 'Curriculum / unit plan',
      action: 'Explain changes',
      title: 'What changed?',
      purpose: `Compare the previously used curriculum material with the curriculum that applies to the intended teaching year, focusing on the practical impact on planning and delivery.`,
      task: `## TASK MODE: EXPLAIN CHANGES
Do not claim that something changed unless you can establish both the earlier position and the newer position from reliable evidence.

Clearly distinguish CURRENT, TRANSITIONAL, FUTURE / DRAFT, or NO LONGER APPLICABLE material where relevant.

Focus on practical implications for teacher planning:
- what can stay;
- what terminology or references must change;
- what emphasis, progression, or structure has changed;
- what does not need to change.

Finish with a short action list titled "What I would change in this unit" based on any supplied material.`,
      fieldsNote: `If the teacher attaches an existing unit or old planning document, compare against that.`
    }
  };
})();
